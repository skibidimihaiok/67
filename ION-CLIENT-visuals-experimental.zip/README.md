# ION CLIENT

## Setup

For setup instructions, please see the [Fabric Documentation page](https://docs.fabricmc.net/develop/getting-started/creating-a-project#setting-up) related to the IDE that you are using.

## License

This template is available under the CC0 license. Feel free to learn from it and incorporate it in your own projects.


## Added in this patch

- **Tracers** (`TracersModule.java`): draws colored 3D ribbons from the local player's eye position to nearby player entities. Includes range, width, and color settings.
- Registered in `ModuleManager` under the Render category.
- Added `EspBatch.line(...)` to submit the line geometry through the existing batched ESP renderer.

### Build

Open this folder as a Gradle project in IntelliJ IDEA and run the Gradle `build` task, or run `gradlew build` from this directory. The project targets Minecraft 1.21.11 and Java 21.

Build with Java 21 using `./gradlew build` (Windows: `gradlew.bat build`). The output JAR is written to `build/libs/`. The source package has been repaired and renamed for ION CLIENT, but this environment could not reach services.gradle.org to download Gradle, so a fresh build could not be verified here.

## Latest experimental additions

- Added **Auto Mace** and **Auto Pearl Catch** entries to the Combat category. These are catalog entries only; their gameplay automation is not implemented yet.
- **Trigger Bot** remains a catalog entry only; its gameplay behaviour is not implemented yet.
- Refreshed the Click GUI with ION CLIENT branding, a purple accent rule, darker layered panels, and clearer enabled/hover states.
- The existing basic per-module toggle keybind code remains included. It is not yet a complete press/hold action-bind system.

This is an experimental source package, not a verified release. Build and test it in Minecraft before using it.

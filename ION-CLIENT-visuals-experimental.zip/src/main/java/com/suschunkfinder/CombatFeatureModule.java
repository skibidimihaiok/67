package com.suschunkfinder;

/** Registered combat feature entry. Behaviour is implemented by dedicated feature classes as they are completed. */
public final class CombatFeatureModule extends ClientModule {
    public CombatFeatureModule(String name, String description) {
        super(name, description, Category.COMBAT);
    }
}

package com.suschunkfinder;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.lwjgl.glfw.GLFW;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;

/** Per-module keyboard and mouse binds. Keyboard codes are non-negative; mouse buttons are -1..-8. */
public final class ModuleKeybinds {
    private static final Map<String, Integer> BINDS = new HashMap<>();
    private static final Set<Integer> DOWN = new HashSet<>();
    private ModuleKeybinds() {}

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.screen != null || client.getWindow() == null) return;
            long window = client.getWindow().handle();
            for (int key = GLFW.GLFW_KEY_SPACE; key <= GLFW.GLFW_KEY_LAST; key++) {
                poll(window, key, GLFW.glfwGetKey(window, key) == GLFW.GLFW_PRESS);
            }
            for (int button = 0; button <= GLFW.GLFW_MOUSE_BUTTON_LAST; button++) {
                poll(window, -button - 1, GLFW.glfwGetMouseButton(window, button) == GLFW.GLFW_PRESS);
            }
        });
    }

    private static void poll(long window, int code, boolean pressed) {
        boolean wasDown = DOWN.contains(code);
        if (pressed && !wasDown) {
            DOWN.add(code);
            for (ClientModule module : ModuleManager.all()) {
                if (get(module) == code) module.setEnabled(!module.isEnabled());
            }
        } else if (!pressed) DOWN.remove(code);
    }

    public static int get(ClientModule module) { return BINDS.getOrDefault(module.name, 0); }
    public static void set(ClientModule module, int code) { BINDS.put(module.name, code); ModuleManager.save(); }
    public static String display(int code) {
        if (code == 0) return "None";
        if (code < 0) return "Mouse " + (-code);
        String name = GLFW.glfwGetKeyName(code, 0);
        if (name != null) return name.toUpperCase();
        return switch (code) {
            case GLFW.GLFW_KEY_LEFT_SHIFT -> "Left Shift"; case GLFW.GLFW_KEY_RIGHT_SHIFT -> "Right Shift";
            case GLFW.GLFW_KEY_LEFT_CONTROL -> "Left Ctrl"; case GLFW.GLFW_KEY_RIGHT_CONTROL -> "Right Ctrl";
            case GLFW.GLFW_KEY_LEFT_ALT -> "Left Alt"; case GLFW.GLFW_KEY_RIGHT_ALT -> "Right Alt";
            case GLFW.GLFW_KEY_SPACE -> "Space"; case GLFW.GLFW_KEY_TAB -> "Tab";
            default -> "Key " + code;
        };
    }
    public static Map<String, Integer> snapshot() { return new HashMap<>(BINDS); }
    public static void load(Map<String, Object> values) {
        BINDS.clear();
        if (values == null) return;
        values.forEach((name, value) -> { if (value instanceof Number n) BINDS.put(name, n.intValue()); });
    }
}

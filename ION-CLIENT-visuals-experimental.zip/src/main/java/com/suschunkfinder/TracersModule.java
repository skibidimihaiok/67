package com.suschunkfinder;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/** Draws configurable lines from the local player's view to other players. */
public final class TracersModule extends ClientModule implements EspSource {
	private final NumberSetting range = add(NumberSetting.of("Range", 128, 8, 256, 8));
	private final NumberSetting width = add(NumberSetting.of("Width", 0.06, 0.02, 0.20, 0.01));
	private final BoolSetting throughWalls = add(BoolSetting.of("Through walls", true));
	private final ModeSetting color = add(ModeSetting.of("Color", 0, "Red", "White", "Cyan", "Yellow", "Green"));

	public TracersModule() {
		super("Tracers", "Draws lines from your view to other players.", Category.RENDER);
	}

	@Override
	public void collect(EspBatch batch, float partialTick) {
		Minecraft client = Minecraft.getInstance();
		if (client.player == null || client.level == null) {
			return;
		}
		float[][] colors = {
			{1.0f, 0.25f, 0.25f},
			{1.0f, 1.0f, 1.0f},
			{0.25f, 0.9f, 1.0f},
			{1.0f, 0.85f, 0.2f},
			{0.25f, 1.0f, 0.4f}
		};
		float[] c = colors[Math.max(0, Math.min(colors.length - 1, color.index()))];
		Vec3 start = client.player.getEyePosition(partialTick);
		double maxDistance = range.get();
		for (Entity entity : client.level.entitiesForRendering()) {
			if (!(entity instanceof Player) || entity == client.player) {
				continue;
			}
			if (client.player.distanceTo(entity) > maxDistance) {
				continue;
			}
			Vec3 feet = entity.getPosition(partialTick);
			Vec3 end = feet.add(0.0, entity.getBbHeight() * 0.5, 0.0);
			batch.line(start, end, c[0], c[1], c[2], 0.95f, width.get());
		}
	}
}

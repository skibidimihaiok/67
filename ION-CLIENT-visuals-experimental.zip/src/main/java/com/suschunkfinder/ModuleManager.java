package com.suschunkfinder;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.loader.api.FabricLoader;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/** Holds every module and saves their on/off state and settings to config/suschunkfinder-client.json. */
public final class ModuleManager {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final List<ClientModule> MODULES = new ArrayList<>();
	private static boolean loading;

	private ModuleManager() {
	}

	public static void init() {
		// Combat feature catalog. Dedicated implementations can be added without changing the GUI or bind system.
        String[][] combat = {
            {"Aura", "Automatically attacks valid nearby targets."},
            {"Auto Crystal", "Crystal placement and detonation helper."},
            {"Criticals", "Critical-hit assistance."},
            {"Anti Knockback", "Configurable knockback handling."},
            {"Trigger Bot", "Attacks when the crosshair is on a valid target."},
            {"Auto Mace", "Crosshair-only spear-to-mace combo helper; behaviour is not implemented yet."},
            {"Auto Pearl Catch", "Configurable manual-activation pearl catch helper; behaviour is not implemented yet."},
            {"Surround", "Places protective blocks around the player."},
            {"Surround Miner", "Mining support for surround combat."},
            {"Auto Totem", "Keeps a totem in the offhand when available."},
            {"Auto Armor", "Equips better available armor."},
            {"Auto Potion", "Potion-use helper."},
            {"Auto Web Trap", "Places webs to hinder nearby targets."},
            {"Auto Wither", "Wither construction helper."},
            {"Offhand", "Offhand item manager."},
            {"Pearl Predict", "Predicts ender-pearl landing positions."},
            {"Projectile Predict", "Predicts incoming projectile paths."},
            {"Trajectories", "Displays projectile trajectories."},
            {"Elytra Target", "Targeting assistance while gliding."},
            {"Elytra Mace Target", "Mace targeting assistance while gliding."},
            {"Elytra Freeze", "Elytra movement control helper."},
            {"Trap", "Builds a trap around a selected target."},
            {"Self Trap", "Builds protective blocks around yourself."},
            {"Anti Aim", "Camera/aim presentation options."},
            {"Anti Phase", "Phase-state detection and visual warning."},
            {"Attribute Swap", "Quick attribute loadout switching."},
            {"Gap", "Golden-apple usage helper."},
            {"Totem", "Totem status and swap helper."}
        };
        for (String[] feature : combat) MODULES.add(new CombatFeatureModule(feature[0], feature[1]));

        // Render
		MODULES.add(new SusChunkModule());
		MODULES.add(new PlayerEspModule());
		MODULES.add(new TracersModule());
		MODULES.add(new MobEspModule());
		MODULES.add(new StorageEspModule());
		MODULES.add(new BlockEntityEspModule());
		MODULES.add(new BlockEspModule());
		MODULES.add(new BlockListModule());
		MODULES.add(new HoleEspModule());
		MODULES.add(new BlockOutlineModule());
		MODULES.add(new JumpCirclesModule());
		MODULES.add(new NameTagsModule());
		MODULES.add(new SpawnerNametagsModule());
		MODULES.add(new RadarModule());
		MODULES.add(new RegionMapModule());
		MODULES.add(new ArmorHudModule());
		MODULES.add(new PotionsModule());
		MODULES.add(new FullbrightModule());
		MODULES.add(new ZoomModule());
		MODULES.add(new CustomFovModule());
		MODULES.add(new CustomCrosshairModule());
		MODULES.add(new HitParticlesModule());
		MODULES.add(new SwingSpeedModule());
		MODULES.add(new FreeLookModule());
		MODULES.add(new CustomGlintModule());
		MODULES.add(new ArmorTrimHiderModule());
		// Movement
		MODULES.add(new AutoWalkModule());
		MODULES.add(new FreecamModule());
		// Macro
		MODULES.add(new ChatMacroModule());
		MODULES.add(new AutoTpaModule());
		// Client
		MODULES.add(new WatermarkModule());
		MODULES.add(new InfoModule());
		MODULES.add(new KeystrokesModule());
		MODULES.add(new ArrayListModule());
		MODULES.add(new NotificationsModule());
		MODULES.add(new SpotifyModule());
		MODULES.add(new HudManagerModule());
		MODULES.add(new IconPickerModule());
		MODULES.add(new ThemeModule());
		MODULES.add(new ClickGuiModule());
		// Misc
		MODULES.add(new StaffListModule());
		MODULES.add(new SpawnerProtectModule());
		MODULES.add(new WeatherNotifierModule());
		MODULES.add(new CoordSnapperModule());
		MODULES.add(new NameProtectModule());
		MODULES.add(new SkinProtectModule());
		MODULES.add(new FastUseModule());
		load();
        ModuleKeybinds.register();

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			for (ClientModule module : MODULES) {
				if (!module.isEnabled()) {
					continue;
				}
				try {
					module.tick(client);
				} catch (Exception ignored) {
					// One broken module should never crash the game.
				}
			}
		});
	}

	/** Finds a module by its class. */
	public static <T extends ClientModule> T find(Class<T> type) {
		for (ClientModule module : MODULES) {
			if (type.isInstance(module)) {
				return type.cast(module);
			}
		}
		return null;
	}

	/** Reads the config file again, used after loading a saved config. */
	public static void reload() {
		load();
	}

	public static List<ClientModule> all() {
		return MODULES;
	}

	public static List<ClientModule> in(ClientModule.Category category) {
		List<ClientModule> list = new ArrayList<>();
		for (ClientModule module : MODULES) {
			if (module.category == category) {
				list.add(module);
			}
		}
		return list;
	}

	public static void renderHud(GuiGraphics graphics) {
		Minecraft client = Minecraft.getInstance();
		if (client.player == null || client.options.hideGui) {
			return;
		}
		for (ClientModule module : MODULES) {
			if (!module.isEnabled()) {
				continue;
			}
			try {
				module.renderHud(graphics);
			} catch (Exception ignored) {
				// One broken HUD element should never crash the game.
			}
		}
	}

	private static Path path() {
		return FabricLoader.getInstance().getConfigDir().resolve("suschunkfinder-client.json");
	}

	public static void save() {
		if (loading) {
			return;
		}
		Map<String, Map<String, Object>> out = new LinkedHashMap<>();
		for (ClientModule module : MODULES) {
			if (!module.persists()) {
				continue;
			}
			Map<String, Object> values = new LinkedHashMap<>();
			values.put("enabled", module.isEnabled());
			for (Setting setting : module.settings()) {
				values.put(setting.name, setting.save());
			}
			out.put(module.name, values);
		}
		out.put("__keybinds", new LinkedHashMap<>(ModuleKeybinds.snapshot()));
		try {
			Files.writeString(path(), GSON.toJson(out));
		} catch (IOException ignored) {
			// Not being able to save is not worth a crash.
		}
	}

	private static void load() {
		loading = true;
		try {
			Path p = path();
			if (!Files.exists(p)) {
				return;
			}
			Type type = new TypeToken<Map<String, Map<String, Object>>>() { }.getType();
			Map<String, Map<String, Object>> in = GSON.fromJson(Files.readString(p), type);
			if (in == null) {
				return;
			}
            ModuleKeybinds.load(in.get("__keybinds"));
			for (ClientModule module : MODULES) {
				Map<String, Object> values = in.get(module.name);
				if (values == null) {
					continue;
				}
				if (values.get("enabled") instanceof Boolean on) {
					module.setEnabled(on);
				}
				for (Setting setting : module.settings()) {
					if (values.containsKey(setting.name)) {
						setting.load(values.get(setting.name));
					}
				}
			}
		} catch (Exception ignored) {
			// A broken config file just means defaults.
		} finally {
			loading = false;
		}
	}
}

package com.suschunkfinder;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;

/** A ring spreads out on the ground each time you jump. */
public final class JumpCirclesModule extends ClientModule implements EspSource {
	private final NumberSetting seconds = add(NumberSetting.of("Duration (s)", 0.8, 0.3, 2.0, 0.1));
	private final NumberSetting size = add(NumberSetting.of("Max size", 1.6, 0.5, 4.0, 0.1));

	private final List<double[]> circles = new ArrayList<>();
	private boolean wasOnGround = true;

	public JumpCirclesModule() {
		super("Jump Circles", "A ring spreads out under you when you jump.", Category.RENDER);
	}

	@Override
	protected void onDisable() {
		circles.clear();
	}

	@Override
	public void tick(Minecraft client) {
		LocalPlayer p = client.player;
		if (p == null) {
			return;
		}
		boolean ground = p.onGround();
		if (wasOnGround && !ground && p.getDeltaMovement().y > 0.2) {
			circles.add(new double[] {p.getX(), p.getY() + 0.02, p.getZ(), System.currentTimeMillis()});
		}
		wasOnGround = ground;
	}

	@Override
	public void collect(EspBatch batch, float pt) {
		long now = System.currentTimeMillis();
		double life = seconds.get() * 1000.0;
		float[] c = ThemeModule.rgb();
		Iterator<double[]> it = circles.iterator();
		while (it.hasNext()) {
			double[] circle = it.next();
			double age = (now - circle[3]) / life;
			if (age >= 1.0) {
				it.remove();
				continue;
			}
			batch.ring(circle[0], circle[1], circle[2], 0.3 + age * size.get(), 0.07, c[0], c[1], c[2], (float) (0.9 * (1.0 - age)));
		}
	}
}

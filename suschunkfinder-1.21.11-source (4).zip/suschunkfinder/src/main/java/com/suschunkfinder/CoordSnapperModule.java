package com.suschunkfinder;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

/** Turn it on once: it copies your coordinates, prints them in chat, then switches itself off. */
public final class CoordSnapperModule extends ClientModule {
	private final BoolSetting copy = add(BoolSetting.of("Copy to clipboard", true));

	public CoordSnapperModule() {
		super("Coord Snapper", "Copies your coordinates and prints them in chat when turned on.", Category.MISC);
	}

	@Override
	protected void onEnable() {
		Minecraft client = Minecraft.getInstance();
		if (client.player == null) {
			return;
		}
		String text = client.player.getBlockX() + " " + client.player.getBlockY() + " " + client.player.getBlockZ();
		if (copy.get()) {
			client.keyboardHandler.setClipboard(text);
		}
		client.player.displayClientMessage(Component.literal("[Coords] " + text), false);
		Notifications.push("Coordinates: " + text);
		setEnabled(false);
	}
}

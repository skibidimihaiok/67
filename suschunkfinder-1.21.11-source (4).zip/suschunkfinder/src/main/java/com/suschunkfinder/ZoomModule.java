package com.suschunkfinder;

import com.mojang.blaze3d.platform.InputConstants;
import org.lwjgl.glfw.GLFW;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;

/** Hold C (rebindable in Controls) to zoom in. */
public final class ZoomModule extends ClientModule {
	private final NumberSetting zoomFov = add(NumberSetting.of("Zoom FOV", 30, 30, 90, 5));
	private final KeyMapping key;
	private Integer saved;

	public ZoomModule() {
		super("Zoom", "Hold the zoom key (C) to zoom in.", Category.RENDER);
		key = KeyBindingHelper.registerKeyBinding(new KeyMapping("key.suschunkfinder.zoom", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_C, Keys.CATEGORY));
	}

	@Override
	public void tick(Minecraft client) {
		if (key.isDown()) {
			if (saved == null) {
				saved = client.options.fov().get();
			}
			client.options.fov().set(zoomFov.getInt());
		} else {
			restore(client);
		}
	}

	@Override
	protected void onDisable() {
		restore(Minecraft.getInstance());
	}

	private void restore(Minecraft client) {
		if (saved != null) {
			client.options.fov().set(saved);
			saved = null;
		}
	}
}

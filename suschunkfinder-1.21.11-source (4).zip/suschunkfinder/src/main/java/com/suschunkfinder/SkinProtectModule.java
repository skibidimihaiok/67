package com.suschunkfinder;

/** Shows default skins instead of the real skins of other players, handy for streaming. */
public final class SkinProtectModule extends ClientModule {
	private final BoolSetting self = add(BoolSetting.of("Include my own skin", false));

	public SkinProtectModule() {
		super("Skin Protect", "Shows default skins instead of real player skins.", Category.MISC);
	}

	public boolean includeSelf() {
		return self.get();
	}
}

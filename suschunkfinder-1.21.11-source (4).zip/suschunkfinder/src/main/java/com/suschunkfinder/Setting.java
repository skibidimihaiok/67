package com.suschunkfinder;

/** One configurable option of a module. */
public abstract class Setting {
	public final String name;

	protected Setting(String name) {
		this.name = name;
	}

	/** Text shown for the current value. */
	public abstract String valueText();

	/** Used by toggle and mode buttons: flips the toggle or goes to the next mode. */
	public abstract void next();

	/** Value written to the config file. */
	public abstract Object save();

	/** Value read back from the config file. */
	public abstract void load(Object value);
}

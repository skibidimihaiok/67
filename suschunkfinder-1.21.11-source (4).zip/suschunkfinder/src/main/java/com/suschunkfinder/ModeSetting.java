package com.suschunkfinder;

import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

public final class ModeSetting extends Setting {
	private final String[] modes;
	private final IntSupplier getter;
	private final IntConsumer setter;

	public ModeSetting(String name, String[] modes, IntSupplier getter, IntConsumer setter) {
		super(name);
		this.modes = modes;
		this.getter = getter;
		this.setter = setter;
	}

	public static ModeSetting of(String name, int def, String... modes) {
		int[] box = {def};
		return new ModeSetting(name, modes, () -> box[0], v -> box[0] = v);
	}

	public int index() {
		return Math.floorMod(getter.getAsInt(), modes.length);
	}

	public String mode() {
		return modes[index()];
	}

	@Override
	public String valueText() {
		return mode();
	}

	@Override
	public void next() {
		setter.accept((index() + 1) % modes.length);
	}

	@Override
	public Object save() {
		return mode();
	}

	@Override
	public void load(Object value) {
		if (value instanceof String s) {
			for (int i = 0; i < modes.length; i++) {
				if (modes[i].equals(s)) {
					setter.accept(i);
				}
			}
		}
	}
}

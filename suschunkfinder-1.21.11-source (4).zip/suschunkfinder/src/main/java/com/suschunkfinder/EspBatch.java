package com.suschunkfinder;

import java.util.function.Supplier;

import com.mojang.blaze3d.vertex.BufferBuilder;
import org.joml.Matrix4fc;

import net.minecraft.world.phys.Vec3;

/** Collects the shapes of all ESP modules for one frame. Coordinates are world coordinates. */
public final class EspBatch {
	private final Matrix4fc pose;
	private final Supplier<BufferBuilder> supplier;
	private final double camX;
	private final double camY;
	private final double camZ;
	private BufferBuilder buffer;
	private int shapes;

	public EspBatch(Matrix4fc pose, Supplier<BufferBuilder> supplier, Vec3 camera) {
		this.pose = pose;
		this.supplier = supplier;
		this.camX = camera.x;
		this.camY = camera.y;
		this.camZ = camera.z;
	}

	public boolean started() {
		return buffer != null;
	}

	public BufferBuilder buffer() {
		return buffer;
	}

	public int shapes() {
		return shapes;
	}

	private BufferBuilder b() {
		if (buffer == null) {
			buffer = supplier.get();
		}
		return buffer;
	}

	private void v(double x, double y, double z, float r, float g, float bl, float a) {
		b().addVertex(pose, (float) (x - camX), (float) (y - camY), (float) (z - camZ)).setColor(r, g, bl, a);
	}

	/** A filled box. */
	public void box(double x0, double y0, double z0, double x1, double y1, double z1, float r, float g, float b, float a) {
		shapes++;
		v(x0, y0, z1, r, g, b, a); v(x1, y0, z1, r, g, b, a); v(x1, y1, z1, r, g, b, a); v(x0, y1, z1, r, g, b, a);
		v(x1, y0, z0, r, g, b, a); v(x0, y0, z0, r, g, b, a); v(x0, y1, z0, r, g, b, a); v(x1, y1, z0, r, g, b, a);
		v(x0, y0, z0, r, g, b, a); v(x0, y0, z1, r, g, b, a); v(x0, y1, z1, r, g, b, a); v(x0, y1, z0, r, g, b, a);
		v(x1, y0, z1, r, g, b, a); v(x1, y0, z0, r, g, b, a); v(x1, y1, z0, r, g, b, a); v(x1, y1, z1, r, g, b, a);
		v(x0, y1, z1, r, g, b, a); v(x1, y1, z1, r, g, b, a); v(x1, y1, z0, r, g, b, a); v(x0, y1, z0, r, g, b, a);
		v(x0, y0, z0, r, g, b, a); v(x1, y0, z0, r, g, b, a); v(x1, y0, z1, r, g, b, a); v(x0, y0, z1, r, g, b, a);
	}

	/** Only the 12 edges of a box, each drawn as a thin box of the given thickness. */
	public void outline(double x0, double y0, double z0, double x1, double y1, double z1, float r, float g, float b, float a, double t) {
		double h = t / 2;
		for (double y : new double[] {y0, y1}) {
			for (double z : new double[] {z0, z1}) {
				box(x0 - h, y - h, z - h, x1 + h, y + h, z + h, r, g, b, a);
			}
		}
		for (double x : new double[] {x0, x1}) {
			for (double z : new double[] {z0, z1}) {
				box(x - h, y0 - h, z - h, x + h, y1 + h, z + h, r, g, b, a);
			}
		}
		for (double x : new double[] {x0, x1}) {
			for (double y : new double[] {y0, y1}) {
				box(x - h, y - h, z0 - h, x + h, y + h, z1 + h, r, g, b, a);
			}
		}
	}

	/** A flat ring lying on the ground, visible from above and below. */
	public void ring(double cx, double cy, double cz, double radius, double width, float r, float g, float b, float a) {
		int n = 32;
		for (int i = 0; i < n; i++) {
			double a0 = Math.PI * 2 * i / n;
			double a1 = Math.PI * 2 * (i + 1) / n;
			double ox0 = cx + Math.cos(a0) * radius;
			double oz0 = cz + Math.sin(a0) * radius;
			double ox1 = cx + Math.cos(a1) * radius;
			double oz1 = cz + Math.sin(a1) * radius;
			double ix0 = cx + Math.cos(a0) * (radius + width);
			double iz0 = cz + Math.sin(a0) * (radius + width);
			double ix1 = cx + Math.cos(a1) * (radius + width);
			double iz1 = cz + Math.sin(a1) * (radius + width);
			v(ox0, cy, oz0, r, g, b, a); v(ox1, cy, oz1, r, g, b, a); v(ix1, cy, iz1, r, g, b, a); v(ix0, cy, iz0, r, g, b, a);
			v(ix0, cy, iz0, r, g, b, a); v(ix1, cy, iz1, r, g, b, a); v(ox1, cy, oz1, r, g, b, a); v(ox0, cy, oz0, r, g, b, a);
		}
		shapes++;
	}
}

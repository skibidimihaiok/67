package com.suschunkfinder;

import java.util.Collection;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;

import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

/**
 * More /suschunk commands:
 * region add|remove|list|clear, friends and staff add|remove|list, base set|clear|info,
 * macro set|list|run, blocks add|remove|list, spotify id|login|play|pause|next|prev.
 */
public final class ExtraCommands {
	private static final int BIG = 30000000;

	private ExtraCommands() {
	}

	public static void register() {
		ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> dispatcher.register(
				ClientCommandManager.literal("suschunk")
						.then(regions())
						.then(names("friends", NameList.FRIENDS))
						.then(names("staff", NameList.STAFF))
						.then(base())
						.then(macros())
						.then(blocks())
						.then(spotify())
		));
	}

	private static void say(FabricClientCommandSource source, String message) {
		source.sendFeedback(Component.literal(message));
	}

	private static LiteralArgumentBuilder<FabricClientCommandSource> regions() {
		return ClientCommandManager.literal("region")
				.then(ClientCommandManager.literal("add")
						.then(ClientCommandManager.argument("name", StringArgumentType.word())
								.then(ClientCommandManager.argument("x1", IntegerArgumentType.integer(-BIG, BIG))
										.then(ClientCommandManager.argument("z1", IntegerArgumentType.integer(-BIG, BIG))
												.then(ClientCommandManager.argument("x2", IntegerArgumentType.integer(-BIG, BIG))
														.then(ClientCommandManager.argument("z2", IntegerArgumentType.integer(-BIG, BIG)).executes(ctx -> {
															String name = StringArgumentType.getString(ctx, "name");
															Regions.add(name,
																	IntegerArgumentType.getInteger(ctx, "x1"), IntegerArgumentType.getInteger(ctx, "z1"),
																	IntegerArgumentType.getInteger(ctx, "x2"), IntegerArgumentType.getInteger(ctx, "z2"));
															say(ctx.getSource(), "Saved region " + name);
															return 1;
														})))))))
				.then(ClientCommandManager.literal("remove")
						.then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(ctx -> {
							String name = StringArgumentType.getString(ctx, "name");
							say(ctx.getSource(), Regions.remove(name) ? "Removed region " + name : "No region called " + name);
							return 1;
						})))
				.then(ClientCommandManager.literal("list").executes(ctx -> {
					if (Regions.all().isEmpty()) {
						say(ctx.getSource(), "No regions yet. Use /suschunk region add <name> <x1> <z1> <x2> <z2>");
					}
					int i = 1;
					for (Regions.Region r : Regions.all()) {
						say(ctx.getSource(), "#" + i + " " + r.name + ": X " + r.minX + " to " + r.maxX + ", Z " + r.minZ + " to " + r.maxZ);
						i++;
					}
					return 1;
				}))
				.then(ClientCommandManager.literal("clear").executes(ctx -> {
					Regions.clear();
					say(ctx.getSource(), "Removed all regions");
					return 1;
				}));
	}

	private static LiteralArgumentBuilder<FabricClientCommandSource> names(String label, NameList list) {
		return ClientCommandManager.literal(label)
				.then(ClientCommandManager.literal("add")
						.then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(ctx -> {
							String name = StringArgumentType.getString(ctx, "name");
							list.add(name);
							say(ctx.getSource(), "Added " + name + " to " + label);
							return 1;
						})))
				.then(ClientCommandManager.literal("remove")
						.then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(ctx -> {
							String name = StringArgumentType.getString(ctx, "name");
							say(ctx.getSource(), list.remove(name) ? "Removed " + name + " from " + label : name + " is not in " + label);
							return 1;
						})))
				.then(ClientCommandManager.literal("list").executes(ctx -> {
					Collection<String> all = list.all();
					say(ctx.getSource(), label + ": " + (all.isEmpty() ? "empty" : String.join(", ", all)));
					return 1;
				}));
	}

	private static LiteralArgumentBuilder<FabricClientCommandSource> base() {
		return ClientCommandManager.literal("base")
				.then(ClientCommandManager.literal("set").executes(ctx -> {
					Minecraft client = Minecraft.getInstance();
					if (client.player == null) {
						return 0;
					}
					SpawnerProtectModule.setBase(client.player.getBlockX(), client.player.getBlockZ());
					say(ctx.getSource(), "Base set to " + SpawnerProtectModule.baseText());
					return 1;
				}))
				.then(ClientCommandManager.literal("clear").executes(ctx -> {
					SpawnerProtectModule.clearBase();
					say(ctx.getSource(), "Base cleared");
					return 1;
				}))
				.then(ClientCommandManager.literal("info").executes(ctx -> {
					say(ctx.getSource(), "Base: " + SpawnerProtectModule.baseText());
					return 1;
				}));
	}

	private static LiteralArgumentBuilder<FabricClientCommandSource> macros() {
		return ClientCommandManager.literal("macro")
				.then(ClientCommandManager.literal("set")
						.then(ClientCommandManager.argument("number", IntegerArgumentType.integer(1, 3))
								.then(ClientCommandManager.argument("text", StringArgumentType.greedyString()).executes(ctx -> {
									int n = IntegerArgumentType.getInteger(ctx, "number");
									ChatMacroModule.set(n, StringArgumentType.getString(ctx, "text"));
									say(ctx.getSource(), "Saved macro " + n);
									return 1;
								}))))
				.then(ClientCommandManager.literal("run")
						.then(ClientCommandManager.argument("number", IntegerArgumentType.integer(1, 3)).executes(ctx -> {
							boolean sent = ChatMacroModule.run(IntegerArgumentType.getInteger(ctx, "number"));
							say(ctx.getSource(), sent ? "Sent" : "Nothing sent (empty macro or too fast)");
							return 1;
						})))
				.then(ClientCommandManager.literal("list").executes(ctx -> {
					for (int i = 1; i <= 3; i++) {
						String text = ChatMacroModule.get(i);
						say(ctx.getSource(), i + ": " + (text.isEmpty() ? "(empty)" : text));
					}
					return 1;
				}));
	}

	private static LiteralArgumentBuilder<FabricClientCommandSource> blocks() {
		return ClientCommandManager.literal("blocks")
				.then(ClientCommandManager.literal("add")
						.then(ClientCommandManager.argument("block", StringArgumentType.word()).executes(ctx -> {
							String id = StringArgumentType.getString(ctx, "block");
							say(ctx.getSource(), BlockListModule.add(id) ? "Added " + id : "Unknown block " + id);
							return 1;
						})))
				.then(ClientCommandManager.literal("remove")
						.then(ClientCommandManager.argument("block", StringArgumentType.word()).executes(ctx -> {
							String id = StringArgumentType.getString(ctx, "block");
							say(ctx.getSource(), BlockListModule.remove(id) ? "Removed " + id : id + " is not in the list");
							return 1;
						})))
				.then(ClientCommandManager.literal("list").executes(ctx -> {
					say(ctx.getSource(), "Blocks: " + (BlockListModule.list().isEmpty() ? "empty" : String.join(", ", BlockListModule.list())));
					return 1;
				}));
	}

	private static LiteralArgumentBuilder<FabricClientCommandSource> spotify() {
		return ClientCommandManager.literal("spotify")
				.then(ClientCommandManager.literal("id")
						.then(ClientCommandManager.argument("clientId", StringArgumentType.word()).executes(ctx -> {
							SpotifyClient.setClientId(StringArgumentType.getString(ctx, "clientId"));
							say(ctx.getSource(), "Spotify Client ID saved. Now run /suschunk spotify login");
							return 1;
						})))
				.then(ClientCommandManager.literal("login").executes(ctx -> {
					if (!SpotifyClient.hasClientId()) {
						say(ctx.getSource(), "Set your Client ID first: /suschunk spotify id <ClientID>");
						return 0;
					}
					try {
						String url = SpotifyClient.beginLogin();
						Minecraft.getInstance().keyboardHandler.setClipboard(url);
						SpotifyClient.start();
						say(ctx.getSource(), "Login link copied. Paste it into your browser and accept. You have 3 minutes.");
					} catch (Exception e) {
						say(ctx.getSource(), "Could not start the login");
					}
					return 1;
				}))
				.then(ClientCommandManager.literal("play").executes(ctx -> control(ctx.getSource(), "play")))
				.then(ClientCommandManager.literal("pause").executes(ctx -> control(ctx.getSource(), "pause")))
				.then(ClientCommandManager.literal("next").executes(ctx -> control(ctx.getSource(), "next")))
				.then(ClientCommandManager.literal("prev").executes(ctx -> control(ctx.getSource(), "prev")));
	}

	private static int control(FabricClientCommandSource source, String action) {
		SpotifyClient.control(action);
		say(source, "Spotify: " + action);
		return 1;
	}
}

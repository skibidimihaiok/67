package com.suschunkfinder;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

/** Small drawing helpers shared by the HUD modules. */
public final class Hud {
	public static final int LINE = 10;
	public static final int WHITE = 0xFFFFFFFF;
	public static final int ACCENT = 0xFF5AA0FF;
	public static final int PANEL = 0x99101820;

	private Hud() {
	}

	/** The accent color picked in the Themes module. */
	public static int accent() {
		return ThemeModule.color();
	}

	/** The shared look of the menu panels: accent border, gradient, bright top bar. */
	public static void panel(GuiGraphics g, int x1, int y1, int x2, int y2) {
		int alpha = ClickGuiModule.panelAlpha() << 24;
		int accent = accent();
		int dim = (accent >> 1) & 0x7F7F7F;
		g.fill(x1 - 1, y1 - 1, x2 + 1, y2 + 1, 0xFF000000 | dim);
		g.fillGradient(x1, y1, x2, y2, alpha | 0x1A2234, alpha | 0x0C111B);
		g.fill(x1, y1, x2, y1 + 3, accent);
	}

	public static Font font() {
		return Minecraft.getInstance().font;
	}

	/** Cuts a text with ".." so it fits the given pixel width. */
	public static String fit(String text, int maxWidth) {
		if (width(text) <= maxWidth) {
			return text;
		}
		String result = text;
		while (result.length() > 1 && width(result + "..") > maxWidth) {
			result = result.substring(0, result.length() - 1);
		}
		return result + "..";
	}

	public static int width(String text) {
		return font().width(text);
	}

	public static void text(GuiGraphics graphics, String text, int x, int y, int color) {
		graphics.drawString(font(), text, x, y, color, true);
	}
}

package com.suschunkfinder;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import com.google.gson.Gson;

import net.fabricmc.loader.api.FabricLoader;

/** A saved list of player names. Used for friends and for the staff list. */
public final class NameList {
	public static final NameList FRIENDS = new NameList("suschunk-friends.json");
	public static final NameList STAFF = new NameList("suschunk-staff.json");

	private static final Gson GSON = new Gson();

	private final String file;
	private final Set<String> names = new LinkedHashSet<>();
	private boolean loaded;

	private NameList(String file) {
		this.file = file;
	}

	private Path path() {
		return FabricLoader.getInstance().getConfigDir().resolve(file);
	}

	private void ensure() {
		if (loaded) {
			return;
		}
		loaded = true;
		try {
			Path p = path();
			if (Files.exists(p)) {
				String[] read = GSON.fromJson(Files.readString(p), String[].class);
				if (read != null) {
					names.addAll(List.of(read));
				}
			}
		} catch (Exception ignored) {
			// A broken file just means an empty list.
		}
	}

	private void save() {
		try {
			Files.writeString(path(), GSON.toJson(names));
		} catch (IOException ignored) {
			// Not being able to save is not worth a crash.
		}
	}

	public Collection<String> all() {
		ensure();
		return new ArrayList<>(names);
	}

	public boolean contains(String name) {
		ensure();
		for (String n : names) {
			if (n.equalsIgnoreCase(name)) {
				return true;
			}
		}
		return false;
	}

	/** True when any saved name appears inside the text, ignoring upper and lower case. */
	public boolean appearsIn(String text) {
		ensure();
		String lower = text.toLowerCase(Locale.ROOT);
		for (String n : names) {
			if (lower.contains(n.toLowerCase(Locale.ROOT))) {
				return true;
			}
		}
		return false;
	}

	public void add(String name) {
		ensure();
		names.add(name);
		save();
	}

	public boolean remove(String name) {
		ensure();
		boolean removed = names.removeIf(n -> n.equalsIgnoreCase(name));
		if (removed) {
			save();
		}
		return removed;
	}
}

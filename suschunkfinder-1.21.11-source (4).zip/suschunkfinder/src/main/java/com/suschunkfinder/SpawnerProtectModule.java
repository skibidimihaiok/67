package com.suschunkfinder;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import com.google.gson.Gson;

import net.fabricmc.loader.api.FabricLoader;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

/**
 * Warns you when a player who is not on your friends list comes close to your base.
 * Set the base with /suschunk base set while standing in it.
 */
public final class SpawnerProtectModule extends ClientModule {
	private static final Gson GSON = new Gson();
	private static int baseX;
	private static int baseZ;
	private static boolean hasBase;
	private static boolean loaded;

	private final NumberSetting radius = add(NumberSetting.of("Radius", 48, 16, 160, 8));
	private final BoolSetting sound = add(BoolSetting.of("Play sound", true));

	private int cooldown;
	private long lastAlert;

	public SpawnerProtectModule() {
		super("Spawner Protect", "Warns you when strangers come near your base. Set it with /suschunk base set.", Category.MISC);
	}

	private static Path path() {
		return FabricLoader.getInstance().getConfigDir().resolve("suschunk-base.json");
	}

	private static void ensure() {
		if (loaded) {
			return;
		}
		loaded = true;
		try {
			Path p = path();
			if (Files.exists(p)) {
				int[] read = GSON.fromJson(Files.readString(p), int[].class);
				if (read != null && read.length == 2) {
					baseX = read[0];
					baseZ = read[1];
					hasBase = true;
				}
			}
		} catch (Exception ignored) {
			// No base saved.
		}
	}

	public static void setBase(int x, int z) {
		ensure();
		baseX = x;
		baseZ = z;
		hasBase = true;
		try {
			Files.writeString(path(), GSON.toJson(new int[] {x, z}));
		} catch (IOException ignored) {
			// Not being able to save is not worth a crash.
		}
	}

	public static void clearBase() {
		ensure();
		hasBase = false;
		try {
			Files.deleteIfExists(path());
		} catch (IOException ignored) {
			// Nothing to delete.
		}
	}

	public static String baseText() {
		ensure();
		return hasBase ? baseX + ", " + baseZ : "not set";
	}

	@Override
	public void tick(Minecraft client) {
		ensure();
		if (!hasBase || client.level == null || client.player == null || cooldown-- > 0) {
			return;
		}
		cooldown = 10;
		double r = radius.get();
		for (Entity entity : client.level.entitiesForRendering()) {
			if (!(entity instanceof Player player) || player == client.player) {
				continue;
			}
			String name = player.getName().getString();
			if (NameList.FRIENDS.contains(name)) {
				continue;
			}
			double dx = player.getX() - baseX;
			double dz = player.getZ() - baseZ;
			if (dx * dx + dz * dz <= r * r && System.currentTimeMillis() - lastAlert > 10000) {
				lastAlert = System.currentTimeMillis();
				Notifications.push("Player near your base: " + name);
				client.player.displayClientMessage(Component.literal("[Spawner Protect] " + name + " is near your base"), false);
				if (sound.get()) {
					client.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.EXPERIENCE_ORB_PICKUP, 1.0f));
				}
				return;
			}
		}
	}
}

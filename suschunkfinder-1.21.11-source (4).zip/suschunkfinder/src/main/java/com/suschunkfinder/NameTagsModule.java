package com.suschunkfinder;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/** Labels above players (and optionally mobs) with name, health and distance. */
public final class NameTagsModule extends ClientModule {
	private final NumberSetting range = add(NumberSetting.of("Range", 64, 16, 128, 8));
	private final BoolSetting mobs = add(BoolSetting.of("Include mobs", false));

	public NameTagsModule() {
		super("Name Tags", "Shows name, health and distance above players.", Category.RENDER);
	}

	@Override
	public void renderHud(GuiGraphics g) {
		Minecraft client = Minecraft.getInstance();
		if (client.level == null || client.player == null) {
			return;
		}
		float pt = client.getDeltaTracker().getGameTimeDeltaPartialTick(false);
		for (Entity entity : client.level.entitiesForRendering()) {
			if (entity == client.player || !(entity instanceof LivingEntity living)) {
				continue;
			}
			if (!(entity instanceof Player) && !mobs.get()) {
				continue;
			}
			float distance = client.player.distanceTo(entity);
			if (distance > range.get()) {
				continue;
			}
			Vec3 top = entity.getPosition(pt).add(0, entity.getBbHeight() + 0.45, 0);
			int[] p = Projector.toScreen(top, pt, g.guiWidth(), g.guiHeight());
			if (p == null) {
				continue;
			}
			String label = entity.getName().getString() + "  " + (int) Math.ceil(living.getHealth()) + "hp  " + (int) distance + "m";
			int w = Hud.width(label);
			g.fill(p[0] - w / 2 - 3, p[1] - 3, p[0] + w / 2 + 3, p[1] + 10, Hud.PANEL);
			Hud.text(g, label, p[0] - w / 2, p[1], Hud.WHITE);
		}
	}
}

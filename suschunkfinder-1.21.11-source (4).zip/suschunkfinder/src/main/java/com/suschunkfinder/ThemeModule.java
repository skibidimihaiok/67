package com.suschunkfinder;

/** Picks the accent color used by the menu and the HUD. This module has no on/off effect, only the setting. */
public final class ThemeModule extends ClientModule {
	private static final int[] COLORS = {0xFF5AA0FF, 0xFFA070FF, 0xFF4CD84C, 0xFFE05050, 0xFFFF9A3C, 0xFFFF6EB4};
	private static ThemeModule instance;

	private final ModeSetting accent = add(ModeSetting.of("Accent", 0, "Blue", "Purple", "Green", "Red", "Orange", "Pink"));

	public ThemeModule() {
		super("Themes", "Changes the accent color of the menu and HUD.", Category.CLIENT);
		instance = this;
	}

	public static int color() {
		return instance == null ? Hud.ACCENT : COLORS[instance.accent.index()];
	}

	/** The accent color as red, green, blue between 0 and 1. */
	public static float[] rgb() {
		int c = color();
		return new float[] {((c >> 16) & 255) / 255f, ((c >> 8) & 255) / 255f, (c & 255) / 255f};
	}
}

package com.suschunkfinder;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import com.google.gson.Gson;
import com.mojang.blaze3d.platform.InputConstants;
import org.lwjgl.glfw.GLFW;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.loader.api.FabricLoader;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;

/**
 * Three saved chat messages or commands. Set them with /suschunk macro set <1-3> <text>, then press the
 * key you bind in Options > Controls (they start unbound) or run /suschunk macro run <n>. One send per second at most.
 */
public final class ChatMacroModule extends ClientModule {
	private static final Gson GSON = new Gson();
	private static final String[] MACROS = {"", "", ""};
	private static boolean loaded;
	private static long lastSent;

	private final KeyMapping[] keys = new KeyMapping[3];

	public ChatMacroModule() {
		super("Chat Macro", "Sends one of three saved messages when you press its key.", Category.MACRO);
		for (int i = 0; i < 3; i++) {
			keys[i] = KeyBindingHelper.registerKeyBinding(new KeyMapping("key.suschunkfinder.macro" + (i + 1),
					InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, Keys.CATEGORY));
		}
	}

	private static Path path() {
		return FabricLoader.getInstance().getConfigDir().resolve("suschunk-macros.json");
	}

	private static void ensure() {
		if (loaded) {
			return;
		}
		loaded = true;
		try {
			Path p = path();
			if (Files.exists(p)) {
				String[] read = GSON.fromJson(Files.readString(p), String[].class);
				if (read != null) {
					for (int i = 0; i < Math.min(3, read.length); i++) {
						MACROS[i] = read[i] == null ? "" : read[i];
					}
				}
			}
		} catch (Exception ignored) {
			// Empty macros are fine.
		}
	}

	public static void set(int number, String text) {
		ensure();
		MACROS[number - 1] = text;
		try {
			Files.writeString(path(), GSON.toJson(MACROS));
		} catch (IOException ignored) {
			// Not being able to save is not worth a crash.
		}
	}

	public static String get(int number) {
		ensure();
		return MACROS[number - 1];
	}

	/** Sends macro 1 to 3, with a one second pause between sends so chat is never spammed. */
	public static boolean run(int number) {
		ensure();
		Minecraft client = Minecraft.getInstance();
		String text = MACROS[number - 1];
		if (client.player == null || text.isBlank() || System.currentTimeMillis() - lastSent < 1000) {
			return false;
		}
		lastSent = System.currentTimeMillis();
		if (text.startsWith("/")) {
			client.player.connection.sendCommand(text.substring(1));
		} else {
			client.player.connection.sendChat(text);
		}
		return true;
	}

	@Override
	public void tick(Minecraft client) {
		for (int i = 0; i < 3; i++) {
			while (keys[i].consumeClick()) {
				run(i + 1);
			}
		}
	}
}

package com.suschunkfinder;

import com.mojang.blaze3d.platform.InputConstants;
import org.lwjgl.glfw.GLFW;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;

import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;

/** The U key opens the client menu. You can rebind it in Options > Controls > Key Binds. */
public final class Keys {
	static final KeyMapping.Category CATEGORY = KeyMapping.Category.register(
			Identifier.fromNamespaceAndPath(SusChunkFinderClient.MOD_ID, "main"));

	private static KeyMapping openGui;

	private Keys() {
	}

	public static void register() {
		openGui = KeyBindingHelper.registerKeyBinding(new KeyMapping(
				"key.suschunkfinder.open_gui",
				InputConstants.Type.KEYSYM,
				GLFW.GLFW_KEY_U,
				CATEGORY
		));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (openGui.consumeClick()) {
				if (client.screen == null && client.player != null) {
					client.setScreen(new ClickGuiScreen());
				}
			}
		});
	}
}

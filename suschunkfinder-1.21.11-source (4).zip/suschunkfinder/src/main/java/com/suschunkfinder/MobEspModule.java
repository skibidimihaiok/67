package com.suschunkfinder;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.phys.AABB;

public final class MobEspModule extends ClientModule implements EspSource {
	private final NumberSetting range = add(NumberSetting.of("Range", 64, 16, 256, 16));
	private final BoolSetting hostile = add(BoolSetting.of("Hostile mobs", true));
	private final BoolSetting passive = add(BoolSetting.of("Passive mobs", true));
	private final BoolSetting fill = add(BoolSetting.of("Filled", false));

	public MobEspModule() {
		super("Mob ESP", "Draws a box around mobs, visible through walls. Hostile red, passive green.", Category.RENDER);
	}

	@Override
	public void collect(EspBatch batch, float pt) {
		Minecraft client = Minecraft.getInstance();
		for (Entity entity : client.level.entitiesForRendering()) {
			if (!(entity instanceof Mob) || client.player.distanceTo(entity) > range.get()) {
				continue;
			}
			boolean isHostile = entity instanceof Enemy;
			if (isHostile ? !hostile.get() : !passive.get()) {
				continue;
			}
			float r = isHostile ? 1f : 0.3f;
			float g = isHostile ? 0.25f : 1f;
			float bl = isHostile ? 0.25f : 0.3f;
			AABB b = EspUtil.lerped(entity, pt);
			batch.outline(b.minX, b.minY, b.minZ, b.maxX, b.maxY, b.maxZ, r, g, bl, 1f, 0.03);
			if (fill.get()) {
				batch.box(b.minX, b.minY, b.minZ, b.maxX, b.maxY, b.maxZ, r, g, bl, 0.18f);
			}
		}
	}
}

package com.suschunkfinder;

import net.minecraft.client.Minecraft;

/** Turn it on to open the HUD manager screen. It switches itself off again. */
public final class HudManagerModule extends ClientModule {
	public HudManagerModule() {
		super("HUD Manager", "Opens a screen to move and switch HUD elements.", Category.CLIENT);
	}

	@Override
	protected void onEnable() {
		Minecraft client = Minecraft.getInstance();
		if (client.player == null) {
			return;
		}
		client.setScreen(new HudManagerScreen(client.screen));
		setEnabled(false);
	}
}

package com.suschunkfinder;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;

/**
 * Reads the chunk data the server already sent to your game and counts blocks that point to a base.
 * It only reads. It sends nothing to the server.
 */
public final class ChunkScanner {
	/** certain = never generates naturally, so one is proof of a player. */
	public enum Kind {
		CHEST("chest", false),
		TRAPPED_CHEST("trapped chest", false),
		BARREL("barrel", false),
		SPAWNER("spawner", false),
		DISPENSER("dispenser", false),
		PISTON("piston", false),
		SHULKER("shulker box", true),
		HOPPER("hopper", true),
		DROPPER("dropper", true),
		OBSERVER("observer", true),
		COMPARATOR("comparator", true),
		REPEATER("repeater", true);

		public final String label;
		public final boolean certain;

		Kind(String label, boolean certain) {
			this.label = label;
			this.certain = certain;
		}
	}

	/** What one chunk contained when it was scanned. */
	public record Result(int cx, int cz, int certain, int total, float meanY, int[] perKind) {
	}

	private static final Map<Block, Kind> KINDS = new HashMap<>();
	private static final Map<Long, Result> RESULTS = new HashMap<>();
	private static final Map<Long, LevelChunk> LOADED = new HashMap<>();
	private static final Set<Long> NOTIFIED = new HashSet<>();
	private static final ArrayDeque<LevelChunk> QUEUE = new ArrayDeque<>();
	private static final int CHUNKS_PER_TICK = 3;

	static {
		KINDS.put(Blocks.CHEST, Kind.CHEST);
		KINDS.put(Blocks.TRAPPED_CHEST, Kind.TRAPPED_CHEST);
		KINDS.put(Blocks.BARREL, Kind.BARREL);
		KINDS.put(Blocks.SPAWNER, Kind.SPAWNER);
		KINDS.put(Blocks.DISPENSER, Kind.DISPENSER);
		KINDS.put(Blocks.PISTON, Kind.PISTON);
		KINDS.put(Blocks.STICKY_PISTON, Kind.PISTON);
		KINDS.put(Blocks.HOPPER, Kind.HOPPER);
		KINDS.put(Blocks.DROPPER, Kind.DROPPER);
		KINDS.put(Blocks.OBSERVER, Kind.OBSERVER);
		KINDS.put(Blocks.COMPARATOR, Kind.COMPARATOR);
		KINDS.put(Blocks.REPEATER, Kind.REPEATER);
	}

	private ChunkScanner() {
	}

	public static void register() {
		ClientChunkEvents.CHUNK_LOAD.register((level, chunk) -> {
			ChunkPos pos = chunk.getPos();
			LOADED.put(key(pos.getMinBlockX() >> 4, pos.getMinBlockZ() >> 4), chunk);
			QUEUE.add(chunk);
		});
		ClientChunkEvents.CHUNK_UNLOAD.register((level, chunk) -> {
			ChunkPos pos = chunk.getPos();
			long key = key(pos.getMinBlockX() >> 4, pos.getMinBlockZ() >> 4);
			LOADED.remove(key);
			RESULTS.remove(key);
		});
		ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> clear());
		ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> clear());
		ClientTickEvents.END_CLIENT_TICK.register(ChunkScanner::tick);
	}

	public static long key(int cx, int cz) {
		return ((long) cx << 32) ^ (cz & 0xffffffffL);
	}

	public static Collection<LevelChunk> loadedChunks() {
		return LOADED.values();
	}

	public static Collection<Result> results() {
		return RESULTS.values();
	}

	public static Result get(int cx, int cz) {
		return RESULTS.get(key(cx, cz));
	}

	private static void clear() {
		QUEUE.clear();
		LOADED.clear();
		RESULTS.clear();
		NOTIFIED.clear();
	}

	/** Scans every loaded chunk again, used after changing the minimum height. */
	public static void rescanAll() {
		QUEUE.clear();
		QUEUE.addAll(LOADED.values());
	}

	private static Kind classify(BlockState state) {
		Block block = state.getBlock();
		Kind kind = KINDS.get(block);
		if (kind == null && block instanceof ShulkerBoxBlock) {
			kind = Kind.SHULKER;
		}
		return kind;
	}

	private static boolean isInteresting(BlockState state) {
		return classify(state) != null;
	}

	/** Scans a few queued chunks per tick so the game never stutters. */
	private static void tick(Minecraft client) {
		if (client.level == null) {
			QUEUE.clear();
			return;
		}
		for (int i = 0; i < CHUNKS_PER_TICK && !QUEUE.isEmpty(); i++) {
			LevelChunk chunk = QUEUE.poll();
			ChunkPos pos = chunk.getPos();
			int cx = pos.getMinBlockX() >> 4;
			int cz = pos.getMinBlockZ() >> 4;
			if (!client.level.getChunkSource().hasChunk(cx, cz)) {
				continue;
			}
			scan(chunk, cx, cz);
		}
	}

	private static void scan(LevelChunk chunk, int cx, int cz) {
		LevelChunkSection[] sections = chunk.getSections();
		int minSection = chunk.getMinSectionY();
		int minY = Config.get().minY;
		int chestMaxY = Config.get().chestMaxY;
		List<int[]> newSpawners = new ArrayList<>();
		int[] perKind = new int[Kind.values().length];
		int total = 0;
		int certain = 0;
		long sumY = 0;

		for (int i = 0; i < sections.length; i++) {
			LevelChunkSection section = sections[i];
			if (section == null || section.hasOnlyAir() || !section.maybeHas(ChunkScanner::isInteresting)) {
				continue;
			}
			int baseY = (minSection + i) << 4;
			if (baseY + 15 < minY) {
				continue;
			}
			for (int y = 0; y < 16; y++) {
				if (baseY + y < minY) {
					continue;
				}
				for (int z = 0; z < 16; z++) {
					for (int x = 0; x < 16; x++) {
						Kind kind = classify(section.getBlockState(x, y, z));
						if (kind == null) {
							continue;
						}
						if ((kind == Kind.CHEST || kind == Kind.TRAPPED_CHEST) && baseY + y > chestMaxY) {
							continue;
						}
						if (kind == Kind.SPAWNER && Config.get().spawnerNotify) {
							int wx = (cx << 4) + x;
							int wz = (cz << 4) + z;
							int wy = baseY + y;
							if (NOTIFIED.add(BlockPos.asLong(wx, wy, wz))) {
								newSpawners.add(new int[] {wx, wy, wz});
							}
						}
						perKind[kind.ordinal()]++;
						total++;
						if (kind.certain) {
							certain++;
						}
						sumY += baseY + y;
					}
				}
			}
		}

		notifySpawners(newSpawners);

		long key = key(cx, cz);
		if (total == 0) {
			RESULTS.remove(key);
		} else {
			RESULTS.put(key, new Result(cx, cz, certain, total, (float) sumY / total, perKind));
		}
	}

	/** Prints new spawners to your chat, a few at a time so a big spawner room does not flood it. */
	private static void notifySpawners(List<int[]> found) {
		Minecraft client = Minecraft.getInstance();
		if (found.isEmpty() || client.player == null) {
			return;
		}
		if (found.size() <= 5) {
			for (int[] p : found) {
				client.player.displayClientMessage(Component.literal("[Spawner Notify] Spawner at X: " + p[0] + " Y: " + p[1] + " Z: " + p[2]), false);
			}
		} else {
			int[] p = found.get(0);
			client.player.displayClientMessage(Component.literal("[Spawner Notify] " + found.size() + " spawners, first at X: " + p[0] + " Y: " + p[1] + " Z: " + p[2]), false);
		}
	}
}

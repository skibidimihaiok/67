package com.suschunkfinder;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Move every HUD element with buttons, and switch them on or off. */
public class HudManagerScreen extends Screen {
	private static final int ROW = 24;
	private static boolean fast;
	private static int page;

	private record Row(HudModule module, int x, int y) {
	}

	private final Screen parent;
	private final List<Row> rows = new ArrayList<>();

	public HudManagerScreen(Screen parent) {
		super(Component.literal("HUD Manager"));
		this.parent = parent;
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	private int left() {
		return this.width / 2 - 145;
	}

	@Override
	protected void init() {
		rows.clear();
		List<HudModule> modules = new ArrayList<>();
		for (ClientModule module : ModuleManager.all()) {
			if (module instanceof HudModule hud) {
				modules.add(hud);
			}
		}

		int top = 56;
		int perPage = Math.max(3, (this.height - top - 56) / ROW);
		int pages = Math.max(1, (modules.size() + perPage - 1) / perPage);
		page = Math.min(page, pages - 1);
		int left = left();
		int start = page * perPage;
		int end = Math.min(modules.size(), start + perPage);

		for (int i = start; i < end; i++) {
			HudModule module = modules.get(i);
			int y = top + (i - start) * ROW;
			rows.add(new Row(module, left, y));

			this.addRenderableWidget(Button.builder(Component.literal(module.isEnabled() ? "ON" : "OFF"), b -> {
				module.setEnabled(!module.isEnabled());
				b.setMessage(Component.literal(module.isEnabled() ? "ON" : "OFF"));
			}).bounds(left + 100, y, 40, 20).build());

			this.addRenderableWidget(Button.builder(Component.literal("-"), b -> nudge(module.xSetting(), false))
					.bounds(left + 146, y, 18, 20).build());
			this.addRenderableWidget(Button.builder(Component.literal("+"), b -> nudge(module.xSetting(), true))
					.bounds(left + 196, y, 18, 20).build());
			this.addRenderableWidget(Button.builder(Component.literal("-"), b -> nudge(module.ySetting(), false))
					.bounds(left + 222, y, 18, 20).build());
			this.addRenderableWidget(Button.builder(Component.literal("+"), b -> nudge(module.ySetting(), true))
					.bounds(left + 272, y, 18, 20).build());
		}

		int bottom = this.height - 30;
		this.addRenderableWidget(Button.builder(Component.literal("Step: " + (fast ? "20" : "5")), b -> {
			fast = !fast;
			b.setMessage(Component.literal("Step: " + (fast ? "20" : "5")));
		}).bounds(left, bottom, 70, 20).build());

		Button prev = Button.builder(Component.literal("<"), b -> {
			page = Math.max(0, page - 1);
			this.rebuildWidgets();
		}).bounds(left + 76, bottom, 24, 20).build();
		prev.active = page > 0;
		this.addRenderableWidget(prev);

		Button next = Button.builder(Component.literal(">"), b -> {
			page = page + 1;
			this.rebuildWidgets();
		}).bounds(left + 104, bottom, 24, 20).build();
		next.active = page < pages - 1;
		this.addRenderableWidget(next);

		this.addRenderableWidget(Button.builder(Component.literal("Done"), b -> this.onClose())
				.bounds(left + 210, bottom, 80, 20).build());
	}

	private static void nudge(NumberSetting setting, boolean up) {
		for (int i = 0; i < (fast ? 4 : 1); i++) {
			setting.change(up);
		}
		ModuleManager.save();
	}

	@Override
	public void onClose() {
		ModuleManager.save();
		this.minecraft.setScreen(parent);
	}

	@Override
	public void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
		super.renderBackground(graphics, mouseX, mouseY, delta);
		Hud.panel(graphics, left() - 12, 10, left() + 302, this.height - 6);
	}

	@Override
	public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
		super.render(graphics, mouseX, mouseY, delta);
		int left = left();
		graphics.drawString(this.font, "HUD Manager", left, 20, Hud.accent());
		graphics.drawString(this.font, "Move HUD elements. X and Y are in screen pixels.", left, 33, 0xFF8890A0);
		graphics.drawString(this.font, "X", left + 172, 44, 0xFF8890A0);
		graphics.drawString(this.font, "Y", left + 248, 44, 0xFF8890A0);
		for (Row row : rows) {
			graphics.drawString(this.font, row.module().name, row.x(), row.y() + 6, Hud.WHITE);
			graphics.drawString(this.font, String.valueOf(row.module().xSetting().getInt()), row.x() + 168, row.y() + 6, Hud.WHITE);
			graphics.drawString(this.font, String.valueOf(row.module().ySetting().getInt()), row.x() + 244, row.y() + 6, Hud.WHITE);
		}
	}
}

package com.suschunkfinder;

import net.minecraft.client.Minecraft;

public final class WeatherNotifierModule extends ClientModule {
	private boolean rain;
	private boolean thunder;
	private boolean ready;

	public WeatherNotifierModule() {
		super("Weather Notifier", "Tells you when rain or thunder starts and stops.", Category.MISC);
	}

	@Override
	protected void onDisable() {
		ready = false;
	}

	@Override
	public void tick(Minecraft client) {
		if (client.level == null || client.player == null) {
			return;
		}
		boolean nowRain = client.level.isRaining();
		boolean nowThunder = client.level.isThundering();
		if (ready) {
			if (nowRain != rain) {
				say(client, nowRain ? "It started raining" : "The rain stopped");
			}
			if (nowThunder != thunder) {
				say(client, nowThunder ? "Thunder started" : "Thunder stopped");
			}
		}
		rain = nowRain;
		thunder = nowThunder;
		ready = true;
	}

	private static void say(Minecraft client, String text) {
		Notifications.push(text);
		client.player.displayClientMessage(net.minecraft.network.chat.Component.literal("[Weather] " + text), false);
	}
}

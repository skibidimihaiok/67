package com.suschunkfinder;

import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.player.ClientInput;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.Vec3;

/**
 * Fly the camera around while your character stands still. Your own input is swapped for an empty one,
 * so nothing extra is sent to the server. It can only show what your game has already received.
 */
public final class FreecamModule extends ClientModule {
	private final NumberSetting speed = add(NumberSetting.of("Speed", 0.6, 0.1, 3.0, 0.1));

	private ClientInput savedInput;
	private LocalPlayer owner;

	public FreecamModule() {
		super("Freecam", "Fly the camera around while your character stays still.", Category.MOVEMENT);
	}

	private void start(Minecraft client) {
		if (client.player == null) {
			return;
		}
		CameraControl.freeLookActive = false;
		Vec3 eye = client.player.getEyePosition();
		CameraControl.x = eye.x;
		CameraControl.y = eye.y;
		CameraControl.z = eye.z;
		CameraControl.px = eye.x;
		CameraControl.py = eye.y;
		CameraControl.pz = eye.z;
		CameraControl.yaw = client.player.getYRot();
		CameraControl.pitch = client.player.getXRot();
		owner = client.player;
		savedInput = client.player.input;
		client.player.input = new ClientInput();
		CameraControl.freecamActive = true;
	}

	private void stop(Minecraft client) {
		CameraControl.freecamActive = false;
		if (client.player != null && client.player == owner && savedInput != null) {
			client.player.input = savedInput;
		}
		savedInput = null;
		owner = null;
	}

	@Override
	protected void onEnable() {
		start(Minecraft.getInstance());
	}

	@Override
	protected void onDisable() {
		stop(Minecraft.getInstance());
	}

	@Override
	public void tick(Minecraft client) {
		if (client.player == null) {
			return;
		}
		if (!CameraControl.freecamActive || owner != client.player) {
			start(client);
		}

		CameraControl.px = CameraControl.x;
		CameraControl.py = CameraControl.y;
		CameraControl.pz = CameraControl.z;
		if (client.screen != null) {
			return;
		}

		Options o = client.options;
		double yaw = Math.toRadians(CameraControl.yaw);
		double pitch = Math.toRadians(CameraControl.pitch);
		double fx = -Math.sin(yaw) * Math.cos(pitch);
		double fy = -Math.sin(pitch);
		double fz = Math.cos(yaw) * Math.cos(pitch);
		double rx = -Math.cos(yaw);
		double rz = -Math.sin(yaw);

		double mx = 0;
		double my = 0;
		double mz = 0;
		if (o.keyUp.isDown()) {
			mx += fx;
			my += fy;
			mz += fz;
		}
		if (o.keyDown.isDown()) {
			mx -= fx;
			my -= fy;
			mz -= fz;
		}
		if (o.keyLeft.isDown()) {
			mx -= rx;
			mz -= rz;
		}
		if (o.keyRight.isDown()) {
			mx += rx;
			mz += rz;
		}
		if (o.keyJump.isDown()) {
			my += 1;
		}
		if (o.keyShift.isDown()) {
			my -= 1;
		}

		double length = Math.sqrt(mx * mx + my * my + mz * mz);
		if (length > 0) {
			double scale = speed.get() / length;
			CameraControl.x += mx * scale;
			CameraControl.y += my * scale;
			CameraControl.z += mz * scale;
		}
	}
}

package com.suschunkfinder;

import net.minecraft.client.Minecraft;

public final class CustomFovModule extends ClientModule {
	private final NumberSetting fov = add(NumberSetting.of("FOV", 90, 30, 110, 5));
	private Integer saved;

	public CustomFovModule() {
		super("Custom FOV", "Sets your field of view while turned on.", Category.RENDER);
	}

	@Override
	public void tick(Minecraft client) {
		if (saved == null) {
			saved = client.options.fov().get();
		}
		client.options.fov().set(fov.getInt());
	}

	@Override
	protected void onDisable() {
		if (saved != null) {
			Minecraft.getInstance().options.fov().set(saved);
			saved = null;
		}
	}
}

package com.suschunkfinder;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.client.gui.GuiGraphics;

/** Lists the modules that are on, in the top right corner. */
public final class ArrayListModule extends ClientModule {
	private final NumberSetting margin = add(NumberSetting.of("Margin", 4, 0, 50, 1));
	private final BoolSetting background = add(BoolSetting.of("Background", true));

	public ArrayListModule() {
		super("Array List", "Lists the modules that are turned on.", Category.CLIENT);
	}

	@Override
	public void renderHud(GuiGraphics g) {
		List<String> names = new ArrayList<>();
		for (ClientModule module : ModuleManager.all()) {
			if (module.isEnabled() && module != this) {
				names.add(module.name);
			}
		}
		names.sort((a, b) -> Integer.compare(Hud.width(b), Hud.width(a)));

		int m = margin.getInt();
		int line = 0;
		for (String name : names) {
			int w = Hud.width(name);
			int x = g.guiWidth() - w - m;
			int y = m + line * (Hud.LINE + 2);
			if (background.get()) {
				g.fill(x - 3, y - 2, x + w + 3, y + Hud.LINE, Hud.PANEL);
				g.fill(x + w + 1, y - 2, x + w + 3, y + Hud.LINE, Hud.accent());
			}
			Hud.text(g, name, x, y, Hud.WHITE);
			line++;
		}
	}
}

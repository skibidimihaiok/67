package com.suschunkfinder;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import net.fabricmc.loader.api.FabricLoader;

/** Saves and loads named copies of all settings. Use /suschunk config save|load|list. */
public final class ConfigManager {
	private ConfigManager() {
	}

	private static Path root() {
		return FabricLoader.getInstance().getConfigDir();
	}

	private static Path dir() {
		return root().resolve("suschunk-configs");
	}

	private static String clean(String name) {
		return name.replaceAll("[^a-zA-Z0-9_-]", "");
	}

	public static boolean save(String name) {
		name = clean(name);
		if (name.isEmpty()) {
			return false;
		}
		try {
			Files.createDirectories(dir());
			ModuleManager.save();
			Config.get().save();
			copy(root().resolve("suschunkfinder-client.json"), dir().resolve(name + "-client.json"));
			copy(root().resolve("suschunkfinder.json"), dir().resolve(name + "-finder.json"));
			return true;
		} catch (IOException e) {
			return false;
		}
	}

	public static boolean load(String name) {
		name = clean(name);
		Path client = dir().resolve(name + "-client.json");
		Path finder = dir().resolve(name + "-finder.json");
		if (name.isEmpty() || !Files.exists(client)) {
			return false;
		}
		try {
			copy(client, root().resolve("suschunkfinder-client.json"));
			if (Files.exists(finder)) {
				copy(finder, root().resolve("suschunkfinder.json"));
			}
			Config.reload();
			ModuleManager.reload();
			return true;
		} catch (IOException e) {
			return false;
		}
	}

	public static List<String> list() {
		List<String> names = new ArrayList<>();
		if (Files.isDirectory(dir())) {
			try (Stream<Path> files = Files.list(dir())) {
				files.map(f -> f.getFileName().toString())
						.filter(f -> f.endsWith("-client.json"))
						.forEach(f -> names.add(f.substring(0, f.length() - "-client.json".length())));
			} catch (IOException ignored) {
				// Nothing to list.
			}
		}
		return names;
	}

	private static void copy(Path from, Path to) throws IOException {
		if (Files.exists(from)) {
			Files.copy(from, to, StandardCopyOption.REPLACE_EXISTING);
		}
	}
}

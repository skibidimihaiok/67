package com.suschunkfinder;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/**
 * The main menu: a search column and one column per category.
 * Left click a module to turn it on or off, right click for its settings, scroll to move a long column.
 */
public class ClickGuiScreen extends Screen {
	private static final int TOP = 14;
	private static final int HEADER = 16;
	private static final int ROW = 14;
	private static final int GAP = 6;
	private static final ClientModule.Category[] CATS = ClientModule.Category.values();
	private static final int[] SCROLL = new int[CATS.length + 1];
	private static String lastSearch = "";

	private EditBox search;
	private int panelW;
	private int startX;

	public ClickGuiScreen() {
		super(Component.literal("Sus Client"));
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	@Override
	protected void init() {
		int n = CATS.length + 1;
		panelW = Math.max(56, Math.min(96, (this.width - 16 - GAP * (n - 1)) / n));
		startX = (this.width - (n * panelW + GAP * (n - 1))) / 2;

		search = new EditBox(this.font, startX + 3, TOP + HEADER + 3, panelW - 6, 14, Component.literal("Search"));
		search.setMaxLength(24);
		search.setValue(lastSearch);
		search.setResponder(value -> {
			lastSearch = value;
			SCROLL[0] = 0;
		});
		this.addRenderableWidget(search);
	}

	private int panelX(int index) {
		return startX + index * (panelW + GAP);
	}

	private int bodyTop(int index) {
		return TOP + HEADER + 2 + (index == 0 ? 20 : 0);
	}

	private List<ClientModule> listFor(int index) {
		if (index > 0) {
			return ModuleManager.in(CATS[index - 1]);
		}
		List<ClientModule> matches = new ArrayList<>();
		String query = lastSearch.trim().toLowerCase(Locale.ROOT);
		if (!query.isEmpty()) {
			for (ClientModule module : ModuleManager.all()) {
				if (module.name.toLowerCase(Locale.ROOT).contains(query)) {
					matches.add(module);
				}
			}
		}
		return matches;
	}

	private int visibleHeight(int index) {
		int content = listFor(index).size() * ROW + 2;
		int max = this.height - bodyTop(index) - 26;
		return Math.max(0, Math.min(content, max));
	}

	/** Finds the module under the mouse. Returns {panel, row} or null. */
	private int[] hit(double mx, double my) {
		for (int i = 0; i <= CATS.length; i++) {
			int x = panelX(i);
			int top = bodyTop(i);
			if (mx < x || mx >= x + panelW || my < top || my >= top + visibleHeight(i)) {
				continue;
			}
			int offset = (int) my - top - 1 + SCROLL[i];
			if (offset < 0) {
				return null;
			}
			int row = offset / ROW;
			return row < listFor(i).size() ? new int[] {i, row} : null;
		}
		return null;
	}

	@Override
	public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
		if (super.mouseClicked(event, doubleClick)) {
			return true;
		}
		int[] found = hit(event.x(), event.y());
		if (found == null) {
			return false;
		}
		ClientModule module = listFor(found[0]).get(found[1]);
		if (event.button() == 1) {
			this.minecraft.setScreen(new ModuleSettingsScreen(module, this));
		} else if (event.button() == 0) {
			module.setEnabled(!module.isEnabled());
		}
		return true;
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
		for (int i = 0; i <= CATS.length; i++) {
			int x = panelX(i);
			if (mouseX >= x && mouseX < x + panelW) {
				int max = Math.max(0, listFor(i).size() * ROW + 2 - visibleHeight(i));
				SCROLL[i] = Math.max(0, Math.min(max, SCROLL[i] - (int) (scrollY * ROW * 2)));
				return true;
			}
		}
		return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
	}

	/** No dimming, so the world stays visible behind the columns. */
	@Override
	public void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
	}

	@Override
	public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
		int accent = Hud.accent();
		int accentFill = (accent & 0x00FFFFFF) | 0xCC000000;
		int panelAlpha = ClickGuiModule.panelAlpha();
		int bodyColor = (panelAlpha << 24) | 0x141822;
		ClientModule hovered = null;

		for (int i = 0; i <= CATS.length; i++) {
			int x = panelX(i);
			String title = i == 0 ? "Search" : CATS[i - 1].label;

			g.fill(x, TOP, x + panelW, TOP + HEADER, 0xF01C2230);
			g.fill(x, TOP + HEADER - 1, x + panelW, TOP + HEADER, accent);
			g.drawString(this.font, title, x + (panelW - this.font.width(title)) / 2, TOP + 4, Hud.WHITE, false);

			List<ClientModule> list = listFor(i);
			int top = bodyTop(i);
			int visible = visibleHeight(i);
			int maxScroll = Math.max(0, list.size() * ROW + 2 - visible);
			SCROLL[i] = Math.max(0, Math.min(SCROLL[i], maxScroll));

			g.fill(x, TOP + HEADER, x + panelW, top + visible, bodyColor);
			if (i == 0 && lastSearch.isBlank()) {
				String hint = "Type a name";
				g.drawString(this.font, hint, x + (panelW - this.font.width(hint)) / 2, top + 4, 0xFF8890A0, false);
			}

			g.enableScissor(x, top, x + panelW, top + visible);
			for (int r = 0; r < list.size(); r++) {
				ClientModule module = list.get(r);
				int y = top + 1 + r * ROW - SCROLL[i];
				if (y + ROW < top || y > top + visible) {
					continue;
				}
				boolean over = mouseX >= x && mouseX < x + panelW && mouseY >= Math.max(y, top)
						&& mouseY < Math.min(y + ROW, top + visible);
				if (over) {
					hovered = module;
				}
				if (module.isEnabled()) {
					g.fill(x, y, x + panelW, y + ROW, accentFill);
				} else if (over) {
					g.fill(x, y, x + panelW, y + ROW, 0x33FFFFFF);
				}
				String name = Hud.fit(module.name, panelW - 8);
				g.drawString(this.font, name, x + (panelW - this.font.width(name)) / 2, y + 3,
						module.isEnabled() ? Hud.WHITE : 0xFFC8CCD6, false);
			}
			g.disableScissor();
		}

		super.render(g, mouseX, mouseY, delta);

		String line = hovered != null
				? hovered.name + ": " + hovered.description
				: "Left click: on/off    Right click: settings    Scroll: move a long column";
		line = Hud.fit(line, this.width - 20);
		g.drawString(this.font, line, this.width / 2 - this.font.width(line) / 2, this.height - 16, 0xFFB0B8C8, true);
	}
}

package com.suschunkfinder;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;

public final class ArmorHudModule extends HudModule {
	private static final EquipmentSlot[] SLOTS = {
			EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
	};

	private final ModeSetting layout = add(ModeSetting.of("Layout", 0, "Vertical", "Horizontal"));
	private final BoolSetting durability = add(BoolSetting.of("Show durability", true));

	public ArmorHudModule() {
		super("Armor HUD", "Shows your armor and how much durability is left.", Category.RENDER, 5, 180);
	}

	@Override
	protected void draw(GuiGraphics g, int x, int y) {
		Minecraft client = Minecraft.getInstance();
		if (client.player == null) {
			return;
		}
		boolean vertical = layout.index() == 0;
		int slot = 0;
		for (EquipmentSlot equipment : SLOTS) {
			ItemStack stack = client.player.getItemBySlot(equipment);
			if (stack.isEmpty()) {
				continue;
			}
			int ix = vertical ? x : x + slot * 40;
			int iy = vertical ? y + slot * 18 : y;
			g.renderItem(stack, ix, iy);
			if (durability.get() && stack.isDamageableItem()) {
				int max = stack.getMaxDamage();
				int percent = (max - stack.getDamageValue()) * 100 / Math.max(1, max);
				Hud.text(g, percent + "%", ix + 18, iy + 4, percent > 25 ? Hud.WHITE : 0xFFFF5555);
			}
			slot++;
		}
	}
}

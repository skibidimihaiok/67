package com.suschunkfinder;

/** Changes how long your own arm swing lasts. Smaller is faster. */
public final class SwingSpeedModule extends ClientModule {
	private final NumberSetting ticks = add(NumberSetting.of("Swing ticks", 6, 1, 20, 1));

	public SwingSpeedModule() {
		super("Swing Speed", "Changes how fast your own arm swings (lower is faster).", Category.RENDER);
	}

	public int duration() {
		return ticks.getInt();
	}
}

package com.suschunkfinder;

/** Shared state for Free Look and Freecam. The camera mixin reads it every frame. */
public final class CameraControl {
	public static boolean freeLookActive;
	public static boolean freecamActive;
	public static float yaw;
	public static float pitch;
	public static double x;
	public static double y;
	public static double z;
	public static double px;
	public static double py;
	public static double pz;

	private CameraControl() {
	}

	/** True while the mouse should steer the camera and not your character. */
	public static boolean active() {
		return freeLookActive || freecamActive;
	}
}

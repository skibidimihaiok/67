package com.suschunkfinder;

import net.minecraft.client.gui.GuiGraphics;

/** Shows the song that is playing on Spotify, with a progress bar. */
public final class SpotifyModule extends HudModule {
	private static final int WIDTH = 150;

	public SpotifyModule() {
		super("Spotify", "Shows what is playing on Spotify. Setup: /suschunk spotify id <ClientID>, then /suschunk spotify login.", Category.CLIENT, 5, 420);
	}

	@Override
	protected void onEnable() {
		SpotifyClient.start();
	}

	private static String fit(String text, int maxWidth) {
		String result = text;
		while (result.length() > 1 && Hud.width(result) > maxWidth) {
			result = result.substring(0, result.length() - 1);
		}
		return result;
	}

	@Override
	protected void draw(GuiGraphics g, int x, int y) {
		SpotifyClient.start();
		g.fill(x - 3, y - 3, x + WIDTH + 3, y + 38, Hud.PANEL);
		g.fill(x - 3, y - 3, x - 1, y + 38, 0xFF1DB954);

		if (!SpotifyClient.hasClientId()) {
			Hud.text(g, "Spotify: set a Client ID", x, y, Hud.WHITE);
			Hud.text(g, fit("/suschunk spotify id <ID>", WIDTH), x, y + Hud.LINE, 0xFF8890A0);
			return;
		}
		if (!SpotifyClient.loggedIn()) {
			Hud.text(g, "Spotify: not logged in", x, y, Hud.WHITE);
			Hud.text(g, "/suschunk spotify login", x, y + Hud.LINE, 0xFF8890A0);
			return;
		}
		if (SpotifyClient.title.isEmpty()) {
			Hud.text(g, "Spotify: nothing playing", x, y, Hud.WHITE);
			return;
		}

		Hud.text(g, fit(SpotifyClient.title, WIDTH), x, y, Hud.WHITE);
		Hud.text(g, fit(SpotifyClient.artist, WIDTH), x, y + Hud.LINE, 0xFF8890A0);

		long duration = Math.max(1, SpotifyClient.durationMs);
		long progress = SpotifyClient.progressMs;
		if (SpotifyClient.playing) {
			progress += System.currentTimeMillis() - SpotifyClient.stamp;
		}
		progress = Math.min(progress, duration);
		int filled = (int) (WIDTH * progress / duration);
		g.fill(x, y + 26, x + WIDTH, y + 29, 0x66FFFFFF);
		g.fill(x, y + 26, x + filled, y + 29, 0xFF1DB954);
		Hud.text(g, SpotifyClient.playing ? "Playing" : "Paused", x, y + 31 - 2, 0xFF8890A0);
	}
}

package com.suschunkfinder;

import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.world.level.block.entity.BarrelBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.DispenserBlockEntity;
import net.minecraft.world.level.block.entity.EnderChestBlockEntity;
import net.minecraft.world.level.block.entity.HopperBlockEntity;
import net.minecraft.world.level.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.world.level.block.entity.TrappedChestBlockEntity;

public final class StorageEspModule extends ClientModule implements EspSource {
	private final NumberSetting range = add(NumberSetting.of("Range (chunks)", 8, 1, 32, 1));
	private final BoolSetting chests = add(BoolSetting.of("Chests", true));
	private final BoolSetting barrels = add(BoolSetting.of("Barrels", true));
	private final BoolSetting shulkers = add(BoolSetting.of("Shulker boxes", true));
	private final BoolSetting enderChests = add(BoolSetting.of("Ender chests", false));
	private final BoolSetting hoppers = add(BoolSetting.of("Hoppers/droppers", true));
	private final BoolSetting furnaces = add(BoolSetting.of("Furnaces", false));
	private final BoolSetting fill = add(BoolSetting.of("Filled", true));

	public StorageEspModule() {
		super("Storage ESP", "Boxes around chests, barrels, shulkers and more, visible through walls.", Category.RENDER);
	}

	/** Colour for a storage block entity, or null when it should not be drawn. */
	private float[] colorOf(BlockEntity be) {
		if (be instanceof TrappedChestBlockEntity) {
			return chests.get() ? new float[] {1f, 0.3f, 0.2f} : null;
		}
		if (be instanceof ChestBlockEntity) {
			return chests.get() ? new float[] {1f, 0.65f, 0.1f} : null;
		}
		if (be instanceof BarrelBlockEntity) {
			return barrels.get() ? new float[] {0.65f, 0.45f, 0.25f} : null;
		}
		if (be instanceof ShulkerBoxBlockEntity) {
			return shulkers.get() ? new float[] {1f, 0.45f, 0.85f} : null;
		}
		if (be instanceof EnderChestBlockEntity) {
			return enderChests.get() ? new float[] {0.6f, 0.3f, 1f} : null;
		}
		if (be instanceof HopperBlockEntity || be instanceof DispenserBlockEntity) {
			return hoppers.get() ? new float[] {0.75f, 0.75f, 0.8f} : null;
		}
		if (be instanceof AbstractFurnaceBlockEntity) {
			return furnaces.get() ? new float[] {0.5f, 0.5f, 0.55f} : null;
		}
		return null;
	}

	@Override
	public void collect(EspBatch batch, float pt) {
		EspUtil.forEachBlockEntity(range.getInt(), be -> {
			float[] c = colorOf(be);
			if (c != null) {
				EspUtil.block(batch, be.getBlockPos(), c, fill.get());
			}
		});
	}
}

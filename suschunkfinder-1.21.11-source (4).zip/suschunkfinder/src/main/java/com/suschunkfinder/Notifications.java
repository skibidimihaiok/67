package com.suschunkfinder;

import java.util.ArrayList;
import java.util.List;

/** Short messages shown on screen by the Notifications module. */
public final class Notifications {
	public record Entry(String text, long expires) {
	}

	private static final List<Entry> ENTRIES = new ArrayList<>();

	private Notifications() {
	}

	public static void push(String text) {
		ENTRIES.add(new Entry(text, System.currentTimeMillis() + 4000));
		if (ENTRIES.size() > 6) {
			ENTRIES.remove(0);
		}
	}

	public static List<Entry> active() {
		long now = System.currentTimeMillis();
		ENTRIES.removeIf(e -> e.expires() < now);
		return ENTRIES;
	}
}

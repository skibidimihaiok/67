package com.suschunkfinder;

/** Forces the enchant shine on every item, or removes it everywhere. */
public final class CustomGlintModule extends ClientModule {
	private final ModeSetting mode = add(ModeSetting.of("Mode", 0, "Always on", "Always off"));

	public CustomGlintModule() {
		super("Custom Glint", "Puts the enchant shine on every item, or takes it off everything.", Category.RENDER);
	}

	public int mode() {
		return mode.index();
	}
}

package com.suschunkfinder;

import net.minecraft.client.gui.GuiGraphics;

public final class WatermarkModule extends HudModule {
	private final ModeSetting style = add(ModeSetting.of("Style", 0, "Plain", "Boxed"));

	public WatermarkModule() {
		super("Watermark", "Shows the client name on your screen.", Category.CLIENT, 5, 5);
	}

	@Override
	protected void draw(GuiGraphics g, int x, int y) {
		String text = IconPickerModule.prefix() + "Sus Client";
		if (style.index() == 1) {
			int w = Hud.width(text);
			g.fill(x - 3, y - 3, x + w + 3, y + Hud.LINE + 1, Hud.PANEL);
			g.fill(x - 3, y - 3, x - 1, y + Hud.LINE + 1, Hud.accent());
		}
		Hud.text(g, text, x, y, Hud.accent());
	}
}

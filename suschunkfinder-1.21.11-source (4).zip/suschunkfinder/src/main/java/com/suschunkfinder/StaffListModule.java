package com.suschunkfinder;

import java.util.LinkedHashSet;
import java.util.Set;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.multiplayer.PlayerInfo;

/** Shows which of the names on your staff list (/suschunk staff add <name>) are online. */
public final class StaffListModule extends HudModule {
	private final BoolSetting showEmpty = add(BoolSetting.of("Show when nobody is online", false));
	private final BoolSetting notify = add(BoolSetting.of("Notify when one joins", true));

	private Set<String> online = new LinkedHashSet<>();
	private int cooldown;

	public StaffListModule() {
		super("Staff List", "Shows which names on your staff list are online.", Category.MISC, 5, 380);
	}

	@Override
	public void tick(Minecraft client) {
		if (cooldown-- > 0) {
			return;
		}
		cooldown = 20;
		ClientPacketListener connection = client.getConnection();
		if (connection == null) {
			return;
		}
		Set<String> now = new LinkedHashSet<>();
		for (PlayerInfo info : connection.getOnlinePlayers()) {
			String name = info.getProfile().name();
			if (NameList.STAFF.contains(name)) {
				now.add(name);
			}
		}
		if (notify.get()) {
			for (String name : now) {
				if (!online.contains(name)) {
					Notifications.push("Staff online: " + name);
				}
			}
		}
		online = now;
	}

	@Override
	protected void draw(GuiGraphics g, int x, int y) {
		if (online.isEmpty() && !showEmpty.get()) {
			return;
		}
		Hud.text(g, "Staff (" + online.size() + ")", x, y, Hud.accent());
		int line = 1;
		for (String name : online) {
			Hud.text(g, name, x, y + line * Hud.LINE, 0xFFFF6060);
			line++;
		}
	}
}

package com.suschunkfinder;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import net.fabricmc.loader.api.FabricLoader;

/** Settings saved in config/suschunkfinder.json. Change them in game with /suschunk. */
public final class Config {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static Config instance;

	/** Show the overlay. */
	public boolean enabled = true;
	/** A chunk turns red when it has at least this many flagged blocks. */
	public int minRed = 2;
	/** A chunk turns green when it has at least this many blocks that never generate naturally. */
	public int minPrime = 1;
	/** Blocks below this height are ignored. Set /suschunk miny -64 to include deepslate levels. */
	public int minY = 0;
	/** Chests and trapped chests above this height are ignored. -64 means only chests at the very bottom count. */
	public int chestMaxY = -64;
	/** Print a chat message with the coordinates when a spawner is found. */
	public boolean spawnerNotify = true;
	/** How far from you, in chunks, the overlay is drawn. */
	public int rangeChunks = 32;
	/** Opacity of the red overlay. The green one is a little stronger. */
	public float alpha = 0.40f;

	public static Config get() {
		if (instance == null) {
			load();
		}
		return instance;
	}

	private static Path path() {
		return FabricLoader.getInstance().getConfigDir().resolve("suschunkfinder.json");
	}

	private static void load() {
		try {
			Path p = path();
			if (Files.exists(p)) {
				instance = GSON.fromJson(Files.readString(p), Config.class);
			}
		} catch (Exception ignored) {
			// Fall back to defaults when the file is missing or broken.
		}
		if (instance == null) {
			instance = new Config();
		}
		instance.save();
	}

	/** Reads the file again into the current object, used when loading a saved config. */
	public static void reload() {
		try {
			Path p = path();
			if (Files.exists(p)) {
				Config fresh = GSON.fromJson(Files.readString(p), Config.class);
				if (fresh != null) {
					get().copyFrom(fresh);
				}
			}
		} catch (Exception ignored) {
			// Keep the current settings if the file cannot be read.
		}
	}

	private void copyFrom(Config o) {
		enabled = o.enabled;
		minRed = o.minRed;
		minPrime = o.minPrime;
		minY = o.minY;
		chestMaxY = o.chestMaxY;
		spawnerNotify = o.spawnerNotify;
		rangeChunks = o.rangeChunks;
		alpha = o.alpha;
	}

	public void save() {
		try {
			Files.writeString(path(), GSON.toJson(this));
		} catch (IOException ignored) {
			// Not being able to save is not worth a crash.
		}
	}
}

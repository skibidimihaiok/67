package com.suschunkfinder;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.level.Level;

/** Shows which map region you are in, plus a small map of all your regions with a dot for you. */
public final class RegionMapModule extends HudModule {
	private static final int[] PALETTE = {0xFF4C9BE8, 0xFFE8A24C, 0xFF58C878, 0xFFD85C8C, 0xFF9C7CE8, 0xFFE0D050, 0xFF50C8C8, 0xFFE07058};

	private final BoolSetting showMap = add(BoolSetting.of("Show map", true));
	private final NumberSetting mapSize = add(NumberSetting.of("Map size", 100, 60, 220, 10));
	private final BoolSetting showCoords = add(BoolSetting.of("Show coordinates", true));

	public RegionMapModule() {
		super("Region Map", "Shows which map region you are in. Add the borders with /suschunk region add.", Category.RENDER, 5, 60);
	}

	@Override
	protected void draw(GuiGraphics g, int x, int y) {
		Minecraft client = Minecraft.getInstance();
		if (client.player == null || client.level == null) {
			return;
		}
		int px = client.player.getBlockX();
		int pz = client.player.getBlockZ();
		boolean overworld = client.level.dimension() == Level.OVERWORLD;

		String line;
		int color = Hud.WHITE;
		if (!overworld) {
			line = "Region: unmapped (not Overworld)";
		} else if (Regions.all().isEmpty()) {
			line = "Region: none set, use /suschunk region add";
		} else {
			Regions.Region region = Regions.find(px, pz);
			if (region == null) {
				line = "Region: outside all regions";
			} else {
				int index = Regions.all().indexOf(region);
				line = "Region: " + region.name + "  (#" + (index + 1) + ")";
				color = PALETTE[index % PALETTE.length];
			}
		}

		int w = Math.max(Hud.width(line), showCoords.get() ? Hud.width("X: " + px + "  Z: " + pz) : 0);
		g.fill(x - 3, y - 3, x + w + 3, y + (showCoords.get() ? Hud.LINE * 2 : Hud.LINE) + 1, Hud.PANEL);
		g.fill(x - 3, y - 3, x - 1, y + (showCoords.get() ? Hud.LINE * 2 : Hud.LINE) + 1, color);
		Hud.text(g, line, x, y, color);
		int next = y + Hud.LINE;
		if (showCoords.get()) {
			Hud.text(g, "X: " + px + "  Z: " + pz, x, next, Hud.WHITE);
			next += Hud.LINE;
		}

		if (!showMap.get() || !overworld || Regions.all().isEmpty()) {
			return;
		}
		drawMap(g, x, next + 4, px, pz);
	}

	private void drawMap(GuiGraphics g, int x, int y, int px, int pz) {
		int minX = Integer.MAX_VALUE;
		int minZ = Integer.MAX_VALUE;
		int maxX = Integer.MIN_VALUE;
		int maxZ = Integer.MIN_VALUE;
		for (Regions.Region r : Regions.all()) {
			minX = Math.min(minX, r.minX);
			minZ = Math.min(minZ, r.minZ);
			maxX = Math.max(maxX, r.maxX);
			maxZ = Math.max(maxZ, r.maxZ);
		}
		double spanX = Math.max(1, maxX - minX);
		double spanZ = Math.max(1, maxZ - minZ);
		int size = mapSize.getInt();
		double scale = size / Math.max(spanX, spanZ);
		int mapW = (int) (spanX * scale);
		int mapH = (int) (spanZ * scale);

		g.fill(x - 1, y - 1, x + mapW + 1, y + mapH + 1, 0xFF000000);
		g.fill(x, y, x + mapW, y + mapH, 0x66202830);

		int i = 0;
		for (Regions.Region r : Regions.all()) {
			int x1 = x + (int) ((r.minX - minX) * scale);
			int z1 = y + (int) ((r.minZ - minZ) * scale);
			int x2 = x + (int) ((r.maxX - minX) * scale);
			int z2 = y + (int) ((r.maxZ - minZ) * scale);
			int c = PALETTE[i % PALETTE.length];
			g.fill(x1, z1, x2, z2, (c & 0x00FFFFFF) | 0x88000000);
			g.fill(x1, z1, x2, z1 + 1, c);
			g.fill(x1, z2 - 1, x2, z2, c);
			g.fill(x1, z1, x1 + 1, z2, c);
			g.fill(x2 - 1, z1, x2, z2, c);
			i++;
		}

		int dotX = x + (int) Math.max(0, Math.min(mapW - 1, (px - minX) * scale));
		int dotZ = y + (int) Math.max(0, Math.min(mapH - 1, (pz - minZ) * scale));
		g.fill(dotX - 2, dotZ - 2, dotX + 3, dotZ + 3, 0xFF000000);
		g.fill(dotX - 1, dotZ - 1, dotX + 2, dotZ + 2, Hud.WHITE);
	}
}

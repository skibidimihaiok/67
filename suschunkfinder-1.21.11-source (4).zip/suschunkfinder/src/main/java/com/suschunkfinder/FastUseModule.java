package com.suschunkfinder;

/** Shortens the pause between right clicks, like placing blocks or using items. */
public final class FastUseModule extends ClientModule {
	private final NumberSetting delay = add(NumberSetting.of("Delay (ticks)", 0, 0, 4, 1));

	public FastUseModule() {
		super("Fast Use", "Shortens the delay between right clicks.", Category.MISC);
	}

	public int delay() {
		return delay.getInt();
	}
}

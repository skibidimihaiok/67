package com.suschunkfinder;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.Vec3;

/** Turns a world position into a screen position, for labels. Close to exact in first person. */
public final class Projector {
	private Projector() {
	}

	/** Returns {x, y} on the GUI, or null when the point is behind you. */
	public static int[] toScreen(Vec3 world, float partialTick, int guiW, int guiH) {
		Minecraft client = Minecraft.getInstance();
		LocalPlayer player = client.player;
		if (player == null) {
			return null;
		}
		Vec3 eye = player.getEyePosition(partialTick);
		double yaw = Math.toRadians(player.getViewYRot(partialTick));
		double pitch = Math.toRadians(player.getViewXRot(partialTick));

		double fx = -Math.sin(yaw) * Math.cos(pitch);
		double fy = -Math.sin(pitch);
		double fz = Math.cos(yaw) * Math.cos(pitch);
		double rx = -Math.cos(yaw);
		double ry = 0;
		double rz = -Math.sin(yaw);
		double ux = ry * fz - rz * fy;
		double uy = rz * fx - rx * fz;
		double uz = rx * fy - ry * fx;

		double dx = world.x - eye.x;
		double dy = world.y - eye.y;
		double dz = world.z - eye.z;
		double depth = dx * fx + dy * fy + dz * fz;
		if (depth < 0.1) {
			return null;
		}
		double right = dx * rx + dy * ry + dz * rz;
		double up = dx * ux + dy * uy + dz * uz;

		double tan = Math.tan(Math.toRadians(client.options.fov().get()) / 2.0);
		double aspect = (double) guiW / guiH;
		int sx = (int) (guiW / 2.0 + right / (depth * tan * aspect) * guiW / 2.0);
		int sy = (int) (guiH / 2.0 - up / (depth * tan) * guiH / 2.0);
		return new int[] {sx, sy};
	}
}

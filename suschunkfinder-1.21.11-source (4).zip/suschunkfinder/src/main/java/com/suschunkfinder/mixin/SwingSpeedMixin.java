package com.suschunkfinder.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.suschunkfinder.ModuleManager;
import com.suschunkfinder.SwingSpeedModule;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;

/** If this target is not found in your game version, the mixin is skipped and the module simply does nothing. */
@Mixin(LivingEntity.class)
public abstract class SwingSpeedMixin {
	@Inject(method = "getCurrentSwingDuration", at = @At("RETURN"), cancellable = true, require = 0)
	private void suschunk$swingDuration(CallbackInfoReturnable<Integer> cir) {
		if ((Object) this != Minecraft.getInstance().player) {
			return;
		}
		SwingSpeedModule module = ModuleManager.find(SwingSpeedModule.class);
		if (module != null && module.isEnabled()) {
			cir.setReturnValue(module.duration());
		}
	}
}

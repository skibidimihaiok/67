package com.suschunkfinder.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

import com.suschunkfinder.FastUseModule;
import com.suschunkfinder.ModuleManager;

import net.minecraft.client.Minecraft;

@Mixin(Minecraft.class)
public abstract class FastUseMixin {
	@ModifyConstant(method = "startUseItem", constant = @Constant(intValue = 4), require = 0)
	private int suschunk$useDelay(int original) {
		FastUseModule module = ModuleManager.find(FastUseModule.class);
		return module != null && module.isEnabled() ? module.delay() : original;
	}
}

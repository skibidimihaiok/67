package com.suschunkfinder.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.suschunkfinder.CustomGlintModule;
import com.suschunkfinder.ModuleManager;

import net.minecraft.world.item.ItemStack;

@Mixin(ItemStack.class)
public abstract class GlintMixin {
	@Inject(method = "hasFoil", at = @At("RETURN"), cancellable = true, require = 0)
	private void suschunk$foil(CallbackInfoReturnable<Boolean> cir) {
		CustomGlintModule module = ModuleManager.find(CustomGlintModule.class);
		if (module == null || !module.isEnabled()) {
			return;
		}
		if (module.mode() == 1) {
			cir.setReturnValue(false);
		} else if (!((ItemStack) (Object) this).isEmpty()) {
			cir.setReturnValue(true);
		}
	}
}

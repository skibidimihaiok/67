package com.suschunkfinder.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.suschunkfinder.CameraControl;

import net.minecraft.client.Camera;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.BlockGetter;

/** Moves and turns the camera for Free Look and Freecam. If the target is missing in your version, this is skipped. */
@Mixin(Camera.class)
public abstract class CameraMixin {
	@Shadow
	protected abstract void setPosition(double x, double y, double z);

	@Shadow
	protected abstract void setRotation(float yRot, float xRot);

	@Inject(method = "setup", at = @At("TAIL"), require = 0)
	private void suschunk$setup(BlockGetter level, Entity entity, boolean detached, boolean mirrored, float partialTick, CallbackInfo ci) {
		if (CameraControl.freecamActive) {
			this.setPosition(
					Mth.lerp((double) partialTick, CameraControl.px, CameraControl.x),
					Mth.lerp((double) partialTick, CameraControl.py, CameraControl.y),
					Mth.lerp((double) partialTick, CameraControl.pz, CameraControl.z));
			this.setRotation(CameraControl.yaw, CameraControl.pitch);
		} else if (CameraControl.freeLookActive) {
			this.setRotation(CameraControl.yaw, CameraControl.pitch);
		}
	}
}

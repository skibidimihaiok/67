package com.suschunkfinder.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.suschunkfinder.ModuleManager;
import com.suschunkfinder.SkinProtectModule;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.world.entity.player.PlayerSkin;

@Mixin(AbstractClientPlayer.class)
public abstract class SkinProtectMixin {
	@Inject(method = "getSkin", at = @At("RETURN"), cancellable = true, require = 0)
	private void suschunk$skin(CallbackInfoReturnable<PlayerSkin> cir) {
		SkinProtectModule module = ModuleManager.find(SkinProtectModule.class);
		AbstractClientPlayer self = (AbstractClientPlayer) (Object) this;
		if (module != null && module.isEnabled() && (self != Minecraft.getInstance().player || module.includeSelf())) {
			cir.setReturnValue(DefaultPlayerSkin.get(self.getUUID()));
		}
	}
}

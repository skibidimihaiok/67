package com.suschunkfinder.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.suschunkfinder.ArmorTrimHiderModule;
import com.suschunkfinder.ModuleManager;

import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.ItemStack;

@Mixin(ItemStack.class)
public abstract class TrimMixin {
	@Inject(method = "get", at = @At("RETURN"), cancellable = true, require = 0)
	private <T> void suschunk$trim(DataComponentType<? extends T> type, CallbackInfoReturnable<T> cir) {
		if (type == DataComponents.TRIM) {
			ArmorTrimHiderModule module = ModuleManager.find(ArmorTrimHiderModule.class);
			if (module != null && module.isEnabled()) {
				cir.setReturnValue(null);
			}
		}
	}
}

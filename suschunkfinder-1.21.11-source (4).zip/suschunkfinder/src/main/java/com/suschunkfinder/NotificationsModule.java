package com.suschunkfinder;

import net.minecraft.client.gui.GuiGraphics;

public final class NotificationsModule extends ClientModule {
	private final NumberSetting y = add(NumberSetting.of("Y", 30, 0, 300, 5));

	public NotificationsModule() {
		super("Notifications", "Shows short messages from modules in the top middle of the screen.", Category.CLIENT);
	}

	@Override
	public void renderHud(GuiGraphics g) {
		int line = 0;
		for (Notifications.Entry entry : Notifications.active()) {
			int w = Hud.width(entry.text());
			int x = g.guiWidth() / 2 - w / 2;
			int yy = y.getInt() + line * 16;
			g.fill(x - 5, yy - 3, x + w + 5, yy + 11, Hud.PANEL);
			g.fill(x - 5, yy - 3, x - 3, yy + 11, Hud.accent());
			Hud.text(g, entry.text(), x, yy, Hud.WHITE);
			line++;
		}
	}
}

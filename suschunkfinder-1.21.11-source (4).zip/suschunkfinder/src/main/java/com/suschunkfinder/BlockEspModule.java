package com.suschunkfinder;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents;

import net.minecraft.client.Minecraft;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;

/** Highlights chosen blocks, such as ores. It only sees blocks the server actually sent. */
public final class BlockEspModule extends ClientModule implements EspSource {
	private static final float[][] COLORS = {
			{0.3f, 0.95f, 1f}, {0.3f, 1f, 0.4f}, {1f, 0.85f, 0.2f}, {0.7f, 0.45f, 0.3f}, {0.3f, 0.4f, 1f}
	};

	private final NumberSetting range = add(NumberSetting.of("Range (chunks)", 6, 1, 16, 1));
	private final BoolSetting diamond = add(BoolSetting.of("Diamond", true).onChange(this::rescan));
	private final BoolSetting emerald = add(BoolSetting.of("Emerald", false).onChange(this::rescan));
	private final BoolSetting gold = add(BoolSetting.of("Gold", false).onChange(this::rescan));
	private final BoolSetting debris = add(BoolSetting.of("Ancient debris", true).onChange(this::rescan));
	private final BoolSetting lapis = add(BoolSetting.of("Lapis", false).onChange(this::rescan));

	private final Map<Long, List<int[]>> found = new HashMap<>();
	private final ArrayDeque<LevelChunk> queue = new ArrayDeque<>();

	public BlockEspModule() {
		super("Block ESP", "Highlights chosen blocks like ores that the server sent to you.", Category.RENDER);
		ClientChunkEvents.CHUNK_LOAD.register((level, chunk) -> {
			if (isEnabled()) {
				queue.add(chunk);
			}
		});
		ClientChunkEvents.CHUNK_UNLOAD.register((level, chunk) -> {
			ChunkPos pos = chunk.getPos();
			found.remove(ChunkScanner.key(pos.getMinBlockX() >> 4, pos.getMinBlockZ() >> 4));
		});
	}

	private int kind(BlockState s) {
		if (diamond.get() && (s.is(Blocks.DIAMOND_ORE) || s.is(Blocks.DEEPSLATE_DIAMOND_ORE))) {
			return 0;
		}
		if (emerald.get() && (s.is(Blocks.EMERALD_ORE) || s.is(Blocks.DEEPSLATE_EMERALD_ORE))) {
			return 1;
		}
		if (gold.get() && (s.is(Blocks.GOLD_ORE) || s.is(Blocks.DEEPSLATE_GOLD_ORE) || s.is(Blocks.NETHER_GOLD_ORE))) {
			return 2;
		}
		if (debris.get() && s.is(Blocks.ANCIENT_DEBRIS)) {
			return 3;
		}
		if (lapis.get() && (s.is(Blocks.LAPIS_ORE) || s.is(Blocks.DEEPSLATE_LAPIS_ORE))) {
			return 4;
		}
		if (BlockListModule.matches(s)) {
			return 5;
		}
		return -1;
	}

	public void rescan() {
		found.clear();
		queue.clear();
		if (isEnabled()) {
			queue.addAll(ChunkScanner.loadedChunks());
		}
	}

	@Override
	protected void onEnable() {
		rescan();
	}

	@Override
	protected void onDisable() {
		found.clear();
		queue.clear();
	}

	@Override
	public void tick(Minecraft client) {
		for (int i = 0; i < 2 && !queue.isEmpty(); i++) {
			scan(queue.poll());
		}
	}

	private void scan(LevelChunk chunk) {
		ChunkPos pos = chunk.getPos();
		int cx = pos.getMinBlockX() >> 4;
		int cz = pos.getMinBlockZ() >> 4;
		List<int[]> list = new ArrayList<>();
		LevelChunkSection[] sections = chunk.getSections();
		int minSection = chunk.getMinSectionY();
		for (int i = 0; i < sections.length; i++) {
			LevelChunkSection section = sections[i];
			if (section == null || section.hasOnlyAir() || !section.maybeHas(s -> kind(s) >= 0)) {
				continue;
			}
			int baseY = (minSection + i) << 4;
			for (int y = 0; y < 16; y++) {
				for (int z = 0; z < 16; z++) {
					for (int x = 0; x < 16; x++) {
						int k = kind(section.getBlockState(x, y, z));
						if (k >= 0) {
							list.add(new int[] {(cx << 4) + x, baseY + y, (cz << 4) + z, k});
						}
					}
				}
			}
		}
		if (list.isEmpty()) {
			found.remove(ChunkScanner.key(cx, cz));
		} else {
			found.put(ChunkScanner.key(cx, cz), list);
		}
	}

	@Override
	public void collect(EspBatch batch, float pt) {
		Minecraft client = Minecraft.getInstance();
		int pcx = client.player.getBlockX() >> 4;
		int pcz = client.player.getBlockZ() >> 4;
		int r = range.getInt();
		int drawn = 0;
		for (Map.Entry<Long, List<int[]>> entry : found.entrySet()) {
			for (int[] p : entry.getValue()) {
				if (Math.abs((p[0] >> 4) - pcx) > r || Math.abs((p[2] >> 4) - pcz) > r) {
					break;
				}
				float[] c = p[3] == 5 ? BlockListModule.rgb() : COLORS[p[3]];
				batch.outline(p[0] + 0.01, p[1] + 0.01, p[2] + 0.01, p[0] + 0.99, p[1] + 0.99, p[2] + 0.99, c[0], c[1], c[2], 1f, 0.03);
				if (++drawn > 600) {
					return;
				}
			}
		}
	}
}

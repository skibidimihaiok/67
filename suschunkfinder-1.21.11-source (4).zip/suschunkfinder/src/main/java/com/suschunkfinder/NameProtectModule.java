package com.suschunkfinder;

import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

/** Replaces your name in incoming chat messages, handy for streaming. Chat colors in those messages are lost. */
public final class NameProtectModule extends ClientModule {
	private final ModeSetting replacement = add(ModeSetting.of("Replace with", 0, "Protected", "You", "Player"));

	public NameProtectModule() {
		super("Name Protect", "Hides your name in chat messages.", Category.MISC);
		ClientReceiveMessageEvents.MODIFY_GAME.register((message, overlay) -> {
			if (!isEnabled() || overlay) {
				return message;
			}
			String name = Minecraft.getInstance().getUser().getName();
			String text = message.getString();
			if (name == null || name.isEmpty() || !text.contains(name)) {
				return message;
			}
			return Component.literal(text.replace(name, replacement.mode()));
		});
	}
}

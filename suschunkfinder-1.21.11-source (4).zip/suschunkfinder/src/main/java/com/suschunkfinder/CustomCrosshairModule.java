package com.suschunkfinder;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;

import net.minecraft.client.gui.GuiGraphics;

/** Replaces the normal crosshair while turned on. */
public final class CustomCrosshairModule extends ClientModule {
	private final ModeSetting style = add(ModeSetting.of("Style", 0, "Cross", "Dot", "Square"));
	private final NumberSetting size = add(NumberSetting.of("Size", 5, 1, 15, 1));
	private final NumberSetting gap = add(NumberSetting.of("Gap", 2, 0, 8, 1));
	private final BoolSetting themed = add(BoolSetting.of("Use theme color", true));

	public CustomCrosshairModule() {
		super("Custom Crosshair", "Draws your own crosshair instead of the normal one.", Category.RENDER);
	}

	/** Hooks into the HUD so the normal crosshair is skipped while this module is on. */
	public static void register() {
		HudElementRegistry.replaceElement(VanillaHudElements.CROSSHAIR, original -> (graphics, tickCounter) -> {
			CustomCrosshairModule module = ModuleManager.find(CustomCrosshairModule.class);
			if (module != null && module.isEnabled()) {
				module.draw(graphics);
			} else {
				original.render(graphics, tickCounter);
			}
		});
	}

	private void draw(GuiGraphics g) {
		int cx = g.guiWidth() / 2;
		int cy = g.guiHeight() / 2;
		int s = size.getInt();
		int gp = gap.getInt();
		int color = themed.get() ? Hud.accent() : Hud.WHITE;
		switch (style.index()) {
			case 1 -> g.fill(cx - 1, cy - 1, cx + 2, cy + 2, color);
			case 2 -> {
				int h = s + gp;
				g.fill(cx - h, cy - h, cx + h + 1, cy - h + 1, color);
				g.fill(cx - h, cy + h, cx + h + 1, cy + h + 1, color);
				g.fill(cx - h, cy - h, cx - h + 1, cy + h + 1, color);
				g.fill(cx + h, cy - h, cx + h + 1, cy + h + 1, color);
			}
			default -> {
				g.fill(cx - gp - s, cy, cx - gp, cy + 1, color);
				g.fill(cx + gp + 1, cy, cx + gp + s + 1, cy + 1, color);
				g.fill(cx, cy - gp - s, cx + 1, cy - gp, color);
				g.fill(cx, cy + gp + 1, cx + 1, cy + gp + s + 1, color);
			}
		}
	}
}

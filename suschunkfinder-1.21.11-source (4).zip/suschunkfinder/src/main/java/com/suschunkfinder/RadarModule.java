package com.suschunkfinder;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;

/** Top-down radar: you in the middle, facing up. */
public final class RadarModule extends HudModule {
	private final NumberSetting size = add(NumberSetting.of("Size", 90, 50, 160, 10));
	private final NumberSetting range = add(NumberSetting.of("Range", 40, 10, 128, 10));
	private final BoolSetting mobs = add(BoolSetting.of("Show mobs", true));

	public RadarModule() {
		super("Radar", "Top-down radar of nearby players and mobs.", Category.RENDER, 5, 300);
	}

	@Override
	protected void draw(GuiGraphics g, int x, int y) {
		Minecraft client = Minecraft.getInstance();
		if (client.level == null || client.player == null) {
			return;
		}
		int s = size.getInt();
		int half = s / 2;
		int cx = x + half;
		int cy = y + half;
		g.fill(x - 1, y - 1, x + s + 1, y + s + 1, 0xAA000000);
		g.fill(x, y, x + s, y + s, 0x66202830);
		g.fill(cx, y, cx + 1, y + s, 0x33FFFFFF);
		g.fill(x, cy, x + s, cy + 1, 0x33FFFFFF);

		double yaw = Math.toRadians(client.player.getYRot());
		double fx = -Math.sin(yaw);
		double fz = Math.cos(yaw);
		double rx = -Math.cos(yaw);
		double rz = -Math.sin(yaw);

		for (Entity entity : client.level.entitiesForRendering()) {
			if (entity == client.player) {
				continue;
			}
			boolean player = entity instanceof Player;
			if (!player && !(mobs.get() && entity instanceof Mob)) {
				continue;
			}
			double dx = entity.getX() - client.player.getX();
			double dz = entity.getZ() - client.player.getZ();
			double forward = dx * fx + dz * fz;
			double right = dx * rx + dz * rz;
			int px = cx + (int) (right / range.get() * half);
			int py = cy - (int) (forward / range.get() * half);
			if (px < x + 1 || px > x + s - 2 || py < y + 1 || py > y + s - 2) {
				continue;
			}
			int color = player ? 0xFFFF4040 : (entity instanceof Enemy ? 0xFFFFA040 : 0xFF50E060);
			g.fill(px - 1, py - 1, px + 2, py + 2, color);
		}
		g.fill(cx - 1, cy - 1, cx + 2, cy + 2, Hud.accent());
	}
}

package com.suschunkfinder;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import com.google.gson.Gson;

import net.fabricmc.loader.api.FabricLoader;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Your own list of blocks for Block ESP. Manage it with /suschunk blocks add|remove|list <block id>,
 * for example /suschunk blocks add minecraft:spawner. Turn this module on to include the list in Block ESP.
 */
public final class BlockListModule extends ClientModule {
	private static final Gson GSON = new Gson();
	private static final float[][] COLORS = {{1f, 0.3f, 0.3f}, {0.3f, 0.9f, 1f}, {1f, 0.5f, 0.85f}, {1f, 1f, 1f}};
	private static final Set<String> IDS = new LinkedHashSet<>();
	private static final Set<Block> BLOCKS = new LinkedHashSet<>();
	private static BlockListModule instance;
	private static boolean loaded;

	private final ModeSetting color = add(ModeSetting.of("Color", 0, "Red", "Cyan", "Pink", "White"));

	public BlockListModule() {
		super("Block List", "Your own block list for Block ESP. Manage it with /suschunk blocks.", Category.RENDER);
		instance = this;
	}

	private static Path path() {
		return FabricLoader.getInstance().getConfigDir().resolve("suschunk-blocks.json");
	}

	private static void ensure() {
		if (loaded) {
			return;
		}
		loaded = true;
		try {
			Path p = path();
			if (Files.exists(p)) {
				String[] read = GSON.fromJson(Files.readString(p), String[].class);
				if (read != null) {
					for (String id : read) {
						resolveAndAdd(id);
					}
				}
			}
		} catch (Exception ignored) {
			// An empty list is fine.
		}
	}

	private static boolean resolveAndAdd(String text) {
		Identifier id = Identifier.tryParse(text.contains(":") ? text : "minecraft:" + text);
		if (id == null) {
			return false;
		}
		Optional<Block> block = BuiltInRegistries.BLOCK.getOptional(id);
		if (block.isEmpty()) {
			return false;
		}
		IDS.add(id.toString());
		BLOCKS.add(block.get());
		return true;
	}

	private static void save() {
		try {
			Files.writeString(path(), GSON.toJson(new ArrayList<>(IDS)));
		} catch (IOException ignored) {
			// Not being able to save is not worth a crash.
		}
	}

	private static void refreshEsp() {
		BlockEspModule esp = ModuleManager.find(BlockEspModule.class);
		if (esp != null) {
			esp.rescan();
		}
	}

	public static boolean add(String text) {
		ensure();
		boolean ok = resolveAndAdd(text);
		if (ok) {
			save();
			refreshEsp();
		}
		return ok;
	}

	public static boolean remove(String text) {
		ensure();
		String id = text.contains(":") ? text : "minecraft:" + text;
		boolean removed = IDS.remove(id);
		if (removed) {
			BLOCKS.clear();
			for (String keep : new ArrayList<>(IDS)) {
				IDS.remove(keep);
				resolveAndAdd(keep);
			}
			save();
			refreshEsp();
		}
		return removed;
	}

	public static List<String> list() {
		ensure();
		return new ArrayList<>(IDS);
	}

	/** True when the list is switched on and contains this block. */
	public static boolean matches(BlockState state) {
		ensure();
		return instance != null && instance.isEnabled() && BLOCKS.contains(state.getBlock());
	}

	public static float[] rgb() {
		return instance == null ? COLORS[0] : COLORS[instance.color.index()];
	}

	@Override
	protected void onEnable() {
		refreshEsp();
	}

	@Override
	protected void onDisable() {
		refreshEsp();
	}
}

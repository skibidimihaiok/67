package com.suschunkfinder;

import net.minecraft.client.gui.GuiGraphics;

/** A module drawn on the HUD at a position you can change with the X and Y settings. */
public abstract class HudModule extends ClientModule {
	private final NumberSetting x;
	private final NumberSetting y;

	protected HudModule(String name, String description, Category category, int defaultX, int defaultY) {
		super(name, description, category);
		this.x = add(NumberSetting.of("X", defaultX, 0, 1000, 5));
		this.y = add(NumberSetting.of("Y", defaultY, 0, 1000, 5));
	}

	public NumberSetting xSetting() {
		return x;
	}

	public NumberSetting ySetting() {
		return y;
	}

	@Override
	public final void renderHud(GuiGraphics graphics) {
		draw(graphics, x.getInt(), y.getInt());
	}

	protected abstract void draw(GuiGraphics graphics, int x, int y);
}

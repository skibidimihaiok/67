package com.suschunkfinder;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/** Marks 1x1 holes walled in by bedrock or obsidian. Green = all bedrock, orange = has obsidian. */
public final class HoleEspModule extends ClientModule implements EspSource {
	private final NumberSetting radius = add(NumberSetting.of("Radius", 6, 2, 12, 1));

	private final List<int[]> holes = new ArrayList<>();
	private int cooldown;

	public HoleEspModule() {
		super("Hole ESP", "Marks safe holes around you.", Category.RENDER);
	}

	private static boolean strong(BlockState s) {
		return s.is(Blocks.BEDROCK) || s.is(Blocks.OBSIDIAN);
	}

	@Override
	protected void onDisable() {
		holes.clear();
	}

	@Override
	public void tick(Minecraft client) {
		if (client.level == null || client.player == null || cooldown-- > 0) {
			return;
		}
		cooldown = 10;
		holes.clear();
		Level level = client.level;
		BlockPos origin = client.player.blockPosition();
		int r = radius.getInt();
		BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
		for (int dx = -r; dx <= r; dx++) {
			for (int dz = -r; dz <= r; dz++) {
				for (int dy = -3; dy <= 2; dy++) {
					p.set(origin.getX() + dx, origin.getY() + dy, origin.getZ() + dz);
					if (!level.getBlockState(p).isAir() || !level.getBlockState(p.above()).isAir()) {
						continue;
					}
					BlockState below = level.getBlockState(p.below());
					BlockState north = level.getBlockState(p.north());
					BlockState south = level.getBlockState(p.south());
					BlockState east = level.getBlockState(p.east());
					BlockState west = level.getBlockState(p.west());
					if (strong(below) && strong(north) && strong(south) && strong(east) && strong(west)) {
						boolean allBedrock = below.is(Blocks.BEDROCK) && north.is(Blocks.BEDROCK) && south.is(Blocks.BEDROCK)
								&& east.is(Blocks.BEDROCK) && west.is(Blocks.BEDROCK);
						holes.add(new int[] {p.getX(), p.getY(), p.getZ(), allBedrock ? 1 : 0});
					}
				}
			}
		}
	}

	@Override
	public void collect(EspBatch batch, float pt) {
		for (int[] h : holes) {
			float r = h[3] == 1 ? 0.2f : 1f;
			float g = h[3] == 1 ? 1f : 0.6f;
			float b = h[3] == 1 ? 0.3f : 0.1f;
			batch.box(h[0] + 0.05, h[1], h[2] + 0.05, h[0] + 0.95, h[1] + 0.06, h[2] + 0.95, r, g, b, 0.45f);
		}
	}
}

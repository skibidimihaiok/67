package com.suschunkfinder;

import net.minecraft.client.Minecraft;

/** Look around freely while your character keeps facing the same way. */
public final class FreeLookModule extends ClientModule {
	public FreeLookModule() {
		super("Free Look", "Look around without turning your character.", Category.RENDER);
	}

	private void start(Minecraft client) {
		if (client.player == null || CameraControl.freecamActive) {
			return;
		}
		CameraControl.yaw = client.player.getYRot();
		CameraControl.pitch = client.player.getXRot();
		CameraControl.freeLookActive = true;
	}

	@Override
	protected void onEnable() {
		start(Minecraft.getInstance());
	}

	@Override
	protected void onDisable() {
		CameraControl.freeLookActive = false;
	}

	@Override
	public void tick(Minecraft client) {
		if (!CameraControl.freeLookActive) {
			start(client);
		}
	}
}

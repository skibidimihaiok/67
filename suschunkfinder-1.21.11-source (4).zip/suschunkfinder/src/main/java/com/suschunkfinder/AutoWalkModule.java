package com.suschunkfinder;

import net.minecraft.client.Minecraft;

/** Holds the forward key for you. */
public final class AutoWalkModule extends ClientModule {
	public AutoWalkModule() {
		super("Auto Walk", "Walks forward on its own until you turn it off.", Category.MOVEMENT);
	}

	@Override
	public void tick(Minecraft client) {
		if (client.screen == null) {
			client.options.keyUp.setDown(true);
		}
	}

	@Override
	protected void onDisable() {
		Minecraft.getInstance().options.keyUp.setDown(false);
	}
}

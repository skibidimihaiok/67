package com.suschunkfinder;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;

import net.minecraft.resources.Identifier;

public class SusChunkFinderClient implements ClientModInitializer {
	public static final String MOD_ID = "suschunkfinder";

	@Override
	public void onInitializeClient() {
		Config.get();
		ModuleManager.init();
		ChunkScanner.register();
		SusRenderer.register();
		EspRenderer.register();
		CustomCrosshairModule.register();
		Commands.register();
		ExtraCommands.register();
		Keys.register();

		HudElementRegistry.attachElementBefore(
				VanillaHudElements.CHAT,
				Identifier.fromNamespaceAndPath(MOD_ID, "hud"),
				(graphics, tickCounter) -> ModuleManager.renderHud(graphics)
		);

		ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
			SusRenderer.close();
			EspRenderer.close();
		});
	}
}

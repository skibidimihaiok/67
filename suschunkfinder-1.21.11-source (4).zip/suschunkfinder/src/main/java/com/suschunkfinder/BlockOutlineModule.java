package com.suschunkfinder;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.shapes.VoxelShape;

public final class BlockOutlineModule extends ClientModule implements EspSource {
	private final NumberSetting thickness = add(NumberSetting.of("Thickness", 0.03, 0.01, 0.1, 0.01));
	private final BoolSetting fill = add(BoolSetting.of("Filled", true));

	public BlockOutlineModule() {
		super("Block Outline", "Outlines the block you are looking at.", Category.RENDER);
	}

	@Override
	public void collect(EspBatch batch, float pt) {
		Minecraft client = Minecraft.getInstance();
		if (!(client.hitResult instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) {
			return;
		}
		BlockPos pos = hit.getBlockPos();
		VoxelShape shape = client.level.getBlockState(pos).getShape(client.level, pos);
		if (shape.isEmpty()) {
			return;
		}
		AABB b = shape.bounds().move(pos);
		float[] c = ThemeModule.rgb();
		batch.outline(b.minX, b.minY, b.minZ, b.maxX, b.maxY, b.maxZ, c[0], c[1], c[2], 1f, thickness.get());
		if (fill.get()) {
			batch.box(b.minX, b.minY, b.minZ, b.maxX, b.maxY, b.maxZ, c[0], c[1], c[2], 0.2f);
		}
	}
}

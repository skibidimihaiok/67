package com.suschunkfinder;

import java.util.Locale;

import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;

import net.minecraft.client.Minecraft;

/**
 * Accepts teleport requests for you, but only from names on your friends list (/suschunk friends add <name>)
 * unless you switch on "Accept anyone". It sends /tpaccept, nothing else.
 */
public final class AutoTpaModule extends ClientModule {
	private final BoolSetting anyone = add(BoolSetting.of("Accept anyone", false));

	private long lastAccept;

	public AutoTpaModule() {
		super("Auto TPA", "Accepts teleport requests from friends automatically.", Category.MACRO);
		ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
			if (!isEnabled() || overlay) {
				return;
			}
			String text = message.getString();
			String lower = text.toLowerCase(Locale.ROOT);
			boolean request = lower.contains("tpa") || lower.contains("teleport");
			boolean asking = lower.contains("request") || lower.contains("wants") || lower.contains("has sent");
			if (!request || !asking || !(anyone.get() || NameList.FRIENDS.appearsIn(text))) {
				return;
			}
			Minecraft client = Minecraft.getInstance();
			if (client.player != null && System.currentTimeMillis() - lastAccept > 2000) {
				lastAccept = System.currentTimeMillis();
				client.execute(() -> client.player.connection.sendCommand("tpaccept"));
				Notifications.push("Accepted a teleport request");
			}
		});
	}
}

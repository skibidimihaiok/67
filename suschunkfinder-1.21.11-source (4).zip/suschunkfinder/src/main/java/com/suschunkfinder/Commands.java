package com.suschunkfinder;

import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;

import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

/**
 * /suschunk toggle | red <n> | prime <n> | range <chunks> | alpha <0.1-1> | miny <y> | chestmax <y> | notify | config save/load/list | info
 * Client commands never reach the server.
 */
public final class Commands {
	private Commands() {
	}

	public static void register() {
		ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> dispatcher.register(
				ClientCommandManager.literal("suschunk")
						.then(ClientCommandManager.literal("toggle").executes(ctx -> {
							Config config = Config.get();
							config.enabled = !config.enabled;
							config.save();
							say(ctx.getSource(), "Sus chunk overlay " + (config.enabled ? "on" : "off"));
							return 1;
						}))
						.then(ClientCommandManager.literal("red")
								.then(ClientCommandManager.argument("count", IntegerArgumentType.integer(1, 200)).executes(ctx -> {
									Config config = Config.get();
									config.minRed = IntegerArgumentType.getInteger(ctx, "count");
									config.save();
									say(ctx.getSource(), "Red chunks need " + config.minRed + " or more flagged blocks");
									return 1;
								})))
						.then(ClientCommandManager.literal("prime")
								.then(ClientCommandManager.argument("count", IntegerArgumentType.integer(1, 200)).executes(ctx -> {
									Config config = Config.get();
									config.minPrime = IntegerArgumentType.getInteger(ctx, "count");
									config.save();
									say(ctx.getSource(), "Green chunks need " + config.minPrime + " or more never-natural blocks");
									return 1;
								})))
						.then(ClientCommandManager.literal("range")
								.then(ClientCommandManager.argument("chunks", IntegerArgumentType.integer(2, 128)).executes(ctx -> {
									Config config = Config.get();
									config.rangeChunks = IntegerArgumentType.getInteger(ctx, "chunks");
									config.save();
									say(ctx.getSource(), "Overlay range set to " + config.rangeChunks + " chunks");
									return 1;
								})))
						.then(ClientCommandManager.literal("miny")
								.then(ClientCommandManager.argument("y", IntegerArgumentType.integer(-64, 320)).executes(ctx -> {
									Config config = Config.get();
									config.minY = IntegerArgumentType.getInteger(ctx, "y");
									config.save();
									ChunkScanner.rescanAll();
									say(ctx.getSource(), "Ignoring blocks below Y " + config.minY);
									return 1;
								})))
						.then(ClientCommandManager.literal("chestmax")
								.then(ClientCommandManager.argument("y", IntegerArgumentType.integer(-64, 320)).executes(ctx -> {
									Config config = Config.get();
									config.chestMaxY = IntegerArgumentType.getInteger(ctx, "y");
									config.save();
									ChunkScanner.rescanAll();
									say(ctx.getSource(), "Chests above Y " + config.chestMaxY + " are ignored");
									return 1;
								})))
						.then(ClientCommandManager.literal("notify").executes(ctx -> {
							Config config = Config.get();
							config.spawnerNotify = !config.spawnerNotify;
							config.save();
							say(ctx.getSource(), "Spawner notify " + (config.spawnerNotify ? "on" : "off"));
							return 1;
						}))
						.then(ClientCommandManager.literal("config")
								.then(ClientCommandManager.literal("save")
										.then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(ctx -> {
											String name = StringArgumentType.getString(ctx, "name");
											say(ctx.getSource(), ConfigManager.save(name) ? "Saved config " + name : "Could not save config");
											return 1;
										})))
								.then(ClientCommandManager.literal("load")
										.then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(ctx -> {
											String name = StringArgumentType.getString(ctx, "name");
											say(ctx.getSource(), ConfigManager.load(name) ? "Loaded config " + name : "No config called " + name);
											return 1;
										})))
								.then(ClientCommandManager.literal("list").executes(ctx -> {
									say(ctx.getSource(), "Configs: " + String.join(", ", ConfigManager.list()));
									return 1;
								})))
						.then(ClientCommandManager.literal("alpha")
								.then(ClientCommandManager.argument("value", FloatArgumentType.floatArg(0.1f, 1f)).executes(ctx -> {
									Config config = Config.get();
									config.alpha = FloatArgumentType.getFloat(ctx, "value");
									config.save();
									say(ctx.getSource(), "Overlay opacity set to " + config.alpha);
									return 1;
								})))
						.then(ClientCommandManager.literal("info").executes(ctx -> {
							Minecraft client = Minecraft.getInstance();
							if (client.player == null) {
								return 0;
							}
							int cx = client.player.getBlockX() >> 4;
							int cz = client.player.getBlockZ() >> 4;
							ChunkScanner.Result result = ChunkScanner.get(cx, cz);
							if (result == null) {
								say(ctx.getSource(), "Chunk " + cx + ", " + cz + ": nothing flagged");
								return 1;
							}
							StringBuilder text = new StringBuilder("Chunk " + cx + ", " + cz + ": ");
							for (ChunkScanner.Kind kind : ChunkScanner.Kind.values()) {
								int count = result.perKind()[kind.ordinal()];
								if (count > 0) {
									text.append(count).append(' ').append(kind.label).append(", ");
								}
							}
							text.append(result.certain()).append(" never-natural");
							say(ctx.getSource(), text.toString());
							return 1;
						}))
		));
	}

	private static void say(FabricClientCommandSource source, String message) {
		source.sendFeedback(Component.literal(message));
	}
}

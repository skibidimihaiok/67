package com.suschunkfinder;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

public final class KeystrokesModule extends HudModule {
	private final NumberSetting size = add(NumberSetting.of("Key size", 18, 12, 30, 2));
	private final BoolSetting showJump = add(BoolSetting.of("Show jump bar", true));

	public KeystrokesModule() {
		super("Keystrokes", "Shows which movement keys you are holding.", Category.CLIENT, 5, 120);
	}

	@Override
	protected void draw(GuiGraphics g, int x, int y) {
		Minecraft client = Minecraft.getInstance();
		int s = size.getInt();
		int gap = 2;

		key(g, "W", client.options.keyUp.isDown(), x + s + gap, y, s, s);
		key(g, "A", client.options.keyLeft.isDown(), x, y + s + gap, s, s);
		key(g, "S", client.options.keyDown.isDown(), x + s + gap, y + s + gap, s, s);
		key(g, "D", client.options.keyRight.isDown(), x + 2 * (s + gap), y + s + gap, s, s);
		if (showJump.get()) {
			key(g, "JUMP", client.options.keyJump.isDown(), x, y + 2 * (s + gap), 3 * s + 2 * gap, s / 2 + 4);
		}
	}

	private static void key(GuiGraphics g, String label, boolean down, int x, int y, int w, int h) {
		g.fill(x, y, x + w, y + h, down ? 0xCC5AA0FF : 0x88000000);
		Hud.text(g, label, x + (w - Hud.width(label)) / 2, y + (h - 8) / 2, Hud.WHITE);
	}
}

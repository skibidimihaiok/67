package com.suschunkfinder;

/** Look of the menu. */
public final class ClickGuiModule extends ClientModule {
	private static ClickGuiModule instance;

	private final NumberSetting opacity = add(NumberSetting.of("Panel opacity %", 75, 30, 100, 5));

	public ClickGuiModule() {
		super("Click GUI", "Settings for the look of this menu.", Category.CLIENT);
		instance = this;
	}

	/** Panel background alpha, 0 to 255. */
	public static int panelAlpha() {
		return instance == null ? 190 : instance.opacity.getInt() * 255 / 100;
	}
}

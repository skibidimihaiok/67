package com.suschunkfinder;

/** A module that draws boxes or rings in the world. */
public interface EspSource {
	void collect(EspBatch batch, float partialTick);
}

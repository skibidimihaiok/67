package com.suschunkfinder;

/** Picks the little symbol shown in front of the watermark. */
public final class IconPickerModule extends ClientModule {
	private static final String[] ICONS = {"", "* ", "+ ", "# ", ">> ", "<3 ", "~ "};
	private static IconPickerModule instance;

	private final ModeSetting icon = add(ModeSetting.of("Icon", 0, "None", "Star", "Plus", "Hash", "Arrows", "Heart", "Wave"));

	public IconPickerModule() {
		super("Icon Picker", "Picks the symbol shown before the watermark text.", Category.CLIENT);
		instance = this;
	}

	public static String prefix() {
		return instance == null ? "" : ICONS[instance.icon.index()];
	}
}

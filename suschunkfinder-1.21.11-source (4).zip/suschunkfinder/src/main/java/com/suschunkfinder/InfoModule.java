package com.suschunkfinder;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

public final class InfoModule extends HudModule {
	private final BoolSetting showFps = add(BoolSetting.of("Show FPS", true));
	private final BoolSetting showCoords = add(BoolSetting.of("Show coordinates", true));

	private int frames;
	private int fps;
	private long windowStart = System.currentTimeMillis();

	public InfoModule() {
		super("Info", "Shows your FPS and coordinates.", Category.CLIENT, 5, 20);
	}

	@Override
	protected void draw(GuiGraphics g, int x, int y) {
		Minecraft client = Minecraft.getInstance();
		if (client.player == null) {
			return;
		}

		frames++;
		long now = System.currentTimeMillis();
		if (now - windowStart >= 1000) {
			fps = frames;
			frames = 0;
			windowStart = now;
		}

		int line = 0;
		if (showFps.get()) {
			Hud.text(g, "FPS: " + fps, x, y + line * Hud.LINE, Hud.WHITE);
			line++;
		}
		if (showCoords.get()) {
			Hud.text(g, "XYZ: " + client.player.getBlockX() + " / " + client.player.getBlockY() + " / " + client.player.getBlockZ(),
					x, y + line * Hud.LINE, Hud.WHITE);
		}
	}
}

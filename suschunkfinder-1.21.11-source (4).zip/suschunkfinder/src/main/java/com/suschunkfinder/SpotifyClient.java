package com.suschunkfinder;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URI;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.fabricmc.loader.api.FabricLoader;

/**
 * Talks to Spotify with your own Spotify developer app (no secret needed, it uses the PKCE login).
 * Setup: create an app at developer.spotify.com, add the redirect URI http://127.0.0.1:8888/callback,
 * then run /suschunk spotify id <ClientID> and /suschunk spotify login. Controlling playback needs Premium.
 */
public final class SpotifyClient {
	private static final String REDIRECT = "http://127.0.0.1:8888/callback";
	private static final String SCOPES = "user-read-currently-playing user-read-playback-state user-modify-playback-state";
	private static final String API = "https://api.spotify.com/v1/me/player";
	private static final Gson GSON = new Gson();

	private static String clientId = "";
	private static String refreshToken = "";
	private static String accessToken = "";
	private static long expiresAt;
	private static String verifier = "";
	private static boolean threadStarted;
	private static boolean loaded;

	public static volatile String title = "";
	public static volatile String artist = "";
	public static volatile boolean playing;
	public static volatile long progressMs;
	public static volatile long durationMs;
	public static volatile long stamp;

	private SpotifyClient() {
	}

	private static Path path() {
		return FabricLoader.getInstance().getConfigDir().resolve("suschunk-spotify.json");
	}

	private static synchronized void load() {
		if (loaded) {
			return;
		}
		loaded = true;
		try {
			Path p = path();
			if (Files.exists(p)) {
				JsonObject json = JsonParser.parseString(Files.readString(p)).getAsJsonObject();
				clientId = json.has("clientId") ? json.get("clientId").getAsString() : "";
				refreshToken = json.has("refreshToken") ? json.get("refreshToken").getAsString() : "";
			}
		} catch (Exception ignored) {
			// Start with nothing saved.
		}
	}

	private static synchronized void save() {
		JsonObject json = new JsonObject();
		json.addProperty("clientId", clientId);
		json.addProperty("refreshToken", refreshToken);
		try {
			Files.writeString(path(), GSON.toJson(json));
		} catch (IOException ignored) {
			// Not being able to save is not worth a crash.
		}
	}

	public static boolean hasClientId() {
		load();
		return !clientId.isEmpty();
	}

	public static boolean loggedIn() {
		load();
		return !refreshToken.isEmpty();
	}

	public static void setClientId(String id) {
		load();
		clientId = id.trim();
		save();
	}

	/** Starts the background thread that checks what is playing every few seconds. */
	public static synchronized void start() {
		load();
		if (threadStarted) {
			return;
		}
		threadStarted = true;
		Thread thread = new Thread(() -> {
			while (true) {
				try {
					if (loggedIn()) {
						poll();
					}
					Thread.sleep(3000);
				} catch (InterruptedException e) {
					return;
				} catch (Exception ignored) {
					// Try again in a few seconds.
				}
			}
		}, "suschunk-spotify");
		thread.setDaemon(true);
		thread.start();
	}

	/** Returns the login link and starts a one-time listener for the answer from Spotify. */
	public static String beginLogin() throws Exception {
		load();
		byte[] random = new byte[48];
		new SecureRandom().nextBytes(random);
		verifier = Base64.getUrlEncoder().withoutPadding().encodeToString(random);
		byte[] hash = MessageDigest.getInstance("SHA-256").digest(verifier.getBytes(StandardCharsets.US_ASCII));
		String challenge = Base64.getUrlEncoder().withoutPadding().encodeToString(hash);

		Thread listener = new Thread(SpotifyClient::listenOnce, "suschunk-spotify-login");
		listener.setDaemon(true);
		listener.start();

		return "https://accounts.spotify.com/authorize?response_type=code"
				+ "&client_id=" + enc(clientId)
				+ "&scope=" + enc(SCOPES)
				+ "&redirect_uri=" + enc(REDIRECT)
				+ "&code_challenge_method=S256&code_challenge=" + challenge;
	}

	private static void listenOnce() {
		try (ServerSocket server = new ServerSocket(8888, 1, InetAddress.getByName("127.0.0.1"))) {
			server.setSoTimeout(180000);
			try (Socket socket = server.accept()) {
				BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
				String line = reader.readLine();
				String code = null;
				if (line != null && line.contains("code=")) {
					String rest = line.substring(line.indexOf("code=") + 5);
					int end = rest.indexOf('&');
					if (end < 0) {
						end = rest.indexOf(' ');
					}
					code = URLDecoder.decode(end < 0 ? rest : rest.substring(0, end), StandardCharsets.UTF_8);
				}
				String body = "<html><body style=\"font-family:sans-serif\"><h2>"
						+ (code != null ? "Logged in. You can close this tab." : "Login failed. Try again in the game.")
						+ "</h2></body></html>";
				byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
				OutputStream out = socket.getOutputStream();
				out.write(("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: " + bytes.length
						+ "\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.US_ASCII));
				out.write(bytes);
				out.flush();
				if (code != null) {
					exchange("grant_type=authorization_code&code=" + enc(code) + "&redirect_uri=" + enc(REDIRECT)
							+ "&client_id=" + enc(clientId) + "&code_verifier=" + enc(verifier));
				}
			}
		} catch (Exception ignored) {
			// The login window timed out or the port was busy.
		}
	}

	private static void exchange(String form) throws IOException {
		String[] response = request("POST", "https://accounts.spotify.com/api/token", form, "application/x-www-form-urlencoded", null);
		if (!"200".equals(response[0])) {
			return;
		}
		JsonObject json = JsonParser.parseString(response[1]).getAsJsonObject();
		accessToken = json.get("access_token").getAsString();
		expiresAt = System.currentTimeMillis() + json.get("expires_in").getAsLong() * 1000;
		if (json.has("refresh_token")) {
			refreshToken = json.get("refresh_token").getAsString();
			save();
		}
	}

	private static void ensureToken() throws IOException {
		if (!accessToken.isEmpty() && System.currentTimeMillis() < expiresAt - 30000) {
			return;
		}
		if (refreshToken.isEmpty()) {
			return;
		}
		exchange("grant_type=refresh_token&refresh_token=" + enc(refreshToken) + "&client_id=" + enc(clientId));
	}

	private static void poll() throws IOException {
		ensureToken();
		if (accessToken.isEmpty()) {
			return;
		}
		String[] response = request("GET", API + "/currently-playing", null, null, accessToken);
		if ("200".equals(response[0]) && !response[1].isEmpty()) {
			JsonObject json = JsonParser.parseString(response[1]).getAsJsonObject();
			playing = json.has("is_playing") && json.get("is_playing").getAsBoolean();
			progressMs = json.has("progress_ms") && !json.get("progress_ms").isJsonNull() ? json.get("progress_ms").getAsLong() : 0;
			stamp = System.currentTimeMillis();
			if (json.has("item") && json.get("item").isJsonObject()) {
				JsonObject item = json.getAsJsonObject("item");
				title = item.has("name") ? item.get("name").getAsString() : "";
				durationMs = item.has("duration_ms") ? item.get("duration_ms").getAsLong() : 0;
				if (item.has("artists") && item.getAsJsonArray("artists").size() > 0) {
					artist = item.getAsJsonArray("artists").get(0).getAsJsonObject().get("name").getAsString();
				}
			}
		} else if ("204".equals(response[0])) {
			playing = false;
		}
	}

	/** action is play, pause, next or prev. */
	public static void control(String action) {
		Thread thread = new Thread(() -> {
			try {
				ensureToken();
				switch (action) {
					case "play" -> request("PUT", API + "/play", null, null, accessToken);
					case "pause" -> request("PUT", API + "/pause", null, null, accessToken);
					case "next" -> request("POST", API + "/next", null, null, accessToken);
					case "prev" -> request("POST", API + "/previous", null, null, accessToken);
					default -> { }
				}
			} catch (Exception ignored) {
				// Controls need Spotify Premium and an active device.
			}
		}, "suschunk-spotify-control");
		thread.setDaemon(true);
		thread.start();
	}

	private static String enc(String text) {
		return URLEncoder.encode(text, StandardCharsets.UTF_8);
	}

	private static String[] request(String method, String url, String body, String contentType, String bearer) throws IOException {
		HttpURLConnection connection = (HttpURLConnection) URI.create(url).toURL().openConnection();
		connection.setRequestMethod(method);
		connection.setConnectTimeout(5000);
		connection.setReadTimeout(8000);
		if (bearer != null) {
			connection.setRequestProperty("Authorization", "Bearer " + bearer);
		}
		if (body != null) {
			connection.setDoOutput(true);
			connection.setRequestProperty("Content-Type", contentType);
			try (OutputStream out = connection.getOutputStream()) {
				out.write(body.getBytes(StandardCharsets.UTF_8));
			}
		} else if (!"GET".equals(method)) {
			connection.setDoOutput(true);
			connection.setFixedLengthStreamingMode(0);
		}
		int code = connection.getResponseCode();
		InputStream in = code >= 400 ? connection.getErrorStream() : connection.getInputStream();
		String text = in == null ? "" : new String(in.readAllBytes(), StandardCharsets.UTF_8);
		return new String[] {String.valueOf(code), text};
	}
}

package com.suschunkfinder;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.effect.MobEffectInstance;

public final class PotionsModule extends HudModule {
	public PotionsModule() {
		super("Potions", "Lists your active potion effects with the time left.", Category.RENDER, 5, 260);
	}

	@Override
	protected void draw(GuiGraphics g, int x, int y) {
		Minecraft client = Minecraft.getInstance();
		if (client.player == null) {
			return;
		}
		int line = 0;
		for (MobEffectInstance effect : client.player.getActiveEffects()) {
			String name = effect.getEffect().value().getDisplayName().getString() + " " + (effect.getAmplifier() + 1);
			String time;
			if (effect.isInfiniteDuration()) {
				time = "inf";
			} else {
				int seconds = effect.getDuration() / 20;
				time = String.format("%d:%02d", seconds / 60, seconds % 60);
			}
			Hud.text(g, name + "  " + time, x, y + line * Hud.LINE, Hud.WHITE);
			line++;
		}
	}
}

package com.suschunkfinder;

import java.util.function.Consumer;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

final class EspUtil {
	private EspUtil() {
	}

	/** The box of an entity, smoothed between ticks so it does not shake. */
	static AABB lerped(Entity entity, float partialTick) {
		Vec3 smooth = entity.getPosition(partialTick);
		Vec3 now = entity.position();
		return entity.getBoundingBox().move(smooth.x - now.x, smooth.y - now.y, smooth.z - now.z);
	}

	static void block(EspBatch batch, BlockPos pos, float[] c, boolean fill) {
		double e = 0.01;
		batch.outline(pos.getX() + e, pos.getY() + e, pos.getZ() + e, pos.getX() + 1 - e, pos.getY() + 1 - e, pos.getZ() + 1 - e, c[0], c[1], c[2], 1f, 0.03);
		if (fill) {
			batch.box(pos.getX() + e, pos.getY() + e, pos.getZ() + e, pos.getX() + 1 - e, pos.getY() + 1 - e, pos.getZ() + 1 - e, c[0], c[1], c[2], 0.22f);
		}
	}

	/** Visits every block entity in loaded chunks within the given range (in chunks). */
	static void forEachBlockEntity(int rangeChunks, Consumer<BlockEntity> action) {
		Minecraft client = Minecraft.getInstance();
		if (client.player == null) {
			return;
		}
		int pcx = client.player.getBlockX() >> 4;
		int pcz = client.player.getBlockZ() >> 4;
		for (LevelChunk chunk : ChunkScanner.loadedChunks()) {
			ChunkPos pos = chunk.getPos();
			int cx = pos.getMinBlockX() >> 4;
			int cz = pos.getMinBlockZ() >> 4;
			if (Math.abs(cx - pcx) > rangeChunks || Math.abs(cz - pcz) > rangeChunks) {
				continue;
			}
			for (BlockEntity entity : chunk.getBlockEntities().values()) {
				action.accept(entity);
			}
		}
	}
}

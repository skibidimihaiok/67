package com.suschunkfinder;

/** The sus chunk finder as a module. It keeps using Config, so /suschunk commands and this GUI stay in sync. */
public final class SusChunkModule extends ClientModule {
	public SusChunkModule() {
		super("Sus Chunk Finder", "Highlights chunks with signs of player activity. Red = flagged, green = prime.", Category.RENDER);
		Config c = Config.get();

		add(new NumberSetting("Red needs", 1, 50, 1, () -> c.minRed, v -> { c.minRed = (int) v; c.save(); }));
		add(new NumberSetting("Green needs", 1, 50, 1, () -> c.minPrime, v -> { c.minPrime = (int) v; c.save(); }));
		add(new NumberSetting("Range", 2, 128, 2, () -> c.rangeChunks, v -> { c.rangeChunks = (int) v; c.save(); }));
		add(new NumberSetting("Ignore below Y", -64, 320, 16, () -> c.minY, v -> { c.minY = (int) v; c.save(); })
				.onChange(ChunkScanner::rescanAll));
		add(new NumberSetting("Chest max Y", -64, 320, 16, () -> c.chestMaxY, v -> { c.chestMaxY = (int) v; c.save(); })
				.onChange(ChunkScanner::rescanAll));
		add(new NumberSetting("Opacity", 0.1, 1.0, 0.1, () -> c.alpha, v -> { c.alpha = (float) v; c.save(); }));
		add(new BoolSetting("Spawner notify", () -> c.spawnerNotify, v -> { c.spawnerNotify = v; c.save(); }));
	}

	@Override
	public boolean isEnabled() {
		return Config.get().enabled;
	}

	@Override
	public void setEnabled(boolean value) {
		Config c = Config.get();
		c.enabled = value;
		c.save();
	}

	@Override
	public boolean persists() {
		return false;
	}
}

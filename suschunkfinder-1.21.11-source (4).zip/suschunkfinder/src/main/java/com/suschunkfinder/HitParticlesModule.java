package com.suschunkfinder;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;

import net.minecraft.client.Minecraft;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.InteractionResult;

/** Extra particles where you hit something. Only you see them. */
public final class HitParticlesModule extends ClientModule {
	private final ModeSetting type = add(ModeSetting.of("Particle", 0, "Crit", "Heart", "Flame", "End rod"));
	private final NumberSetting amount = add(NumberSetting.of("Amount", 8, 1, 30, 1));

	public HitParticlesModule() {
		super("Hit Particles", "Spawns extra particles where you hit something.", Category.RENDER);
		AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
			Minecraft client = Minecraft.getInstance();
			if (isEnabled() && client.level == world) {
				ParticleOptions particle = switch (type.index()) {
					case 1 -> ParticleTypes.HEART;
					case 2 -> ParticleTypes.FLAME;
					case 3 -> ParticleTypes.END_ROD;
					default -> ParticleTypes.CRIT;
				};
				for (int i = 0; i < amount.getInt(); i++) {
					world.addParticle(particle,
							entity.getX() + (Math.random() - 0.5) * entity.getBbWidth(),
							entity.getY() + Math.random() * entity.getBbHeight(),
							entity.getZ() + (Math.random() - 0.5) * entity.getBbWidth(),
							(Math.random() - 0.5) * 0.2, Math.random() * 0.2, (Math.random() - 0.5) * 0.2);
				}
			}
			return InteractionResult.PASS;
		});
	}
}

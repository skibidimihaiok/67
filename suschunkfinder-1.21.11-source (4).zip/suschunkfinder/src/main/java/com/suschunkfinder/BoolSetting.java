package com.suschunkfinder;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

public final class BoolSetting extends Setting {
	private final BooleanSupplier getter;
	private final Consumer<Boolean> setter;
	private Runnable onChange = () -> { };

	public BoolSetting(String name, BooleanSupplier getter, Consumer<Boolean> setter) {
		super(name);
		this.getter = getter;
		this.setter = setter;
	}

	public static BoolSetting of(String name, boolean def) {
		boolean[] box = {def};
		return new BoolSetting(name, () -> box[0], v -> box[0] = v);
	}

	/** Runs after every change. */
	public BoolSetting onChange(Runnable action) {
		this.onChange = action;
		return this;
	}

	public boolean get() {
		return getter.getAsBoolean();
	}

	public void set(boolean value) {
		setter.accept(value);
		onChange.run();
	}

	@Override
	public String valueText() {
		return get() ? "ON" : "OFF";
	}

	@Override
	public void next() {
		set(!get());
	}

	@Override
	public Object save() {
		return get();
	}

	@Override
	public void load(Object value) {
		if (value instanceof Boolean b) {
			set(b);
		}
	}
}

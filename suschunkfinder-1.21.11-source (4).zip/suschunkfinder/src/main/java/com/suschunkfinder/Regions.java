package com.suschunkfinder;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import net.fabricmc.loader.api.FabricLoader;

/** Rectangles of the server map, saved in config/suschunk-regions.json. You add the real borders with /suschunk region add. */
public final class Regions {
	public static final class Region {
		public String name;
		public int minX;
		public int minZ;
		public int maxX;
		public int maxZ;

		public boolean contains(int x, int z) {
			return x >= minX && x <= maxX && z >= minZ && z <= maxZ;
		}
	}

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static List<Region> regions;

	private Regions() {
	}

	private static Path path() {
		return FabricLoader.getInstance().getConfigDir().resolve("suschunk-regions.json");
	}

	public static List<Region> all() {
		if (regions == null) {
			regions = new ArrayList<>();
			try {
				Path p = path();
				if (Files.exists(p)) {
					Type type = new TypeToken<List<Region>>() { }.getType();
					List<Region> loaded = GSON.fromJson(Files.readString(p), type);
					if (loaded != null) {
						regions.addAll(loaded);
					}
				}
			} catch (Exception ignored) {
				// A broken file just means no regions.
			}
		}
		return regions;
	}

	/** The first region that contains this spot, or null. */
	public static Region find(int x, int z) {
		for (Region region : all()) {
			if (region.contains(x, z)) {
				return region;
			}
		}
		return null;
	}

	public static void add(String name, int x1, int z1, int x2, int z2) {
		remove(name);
		Region region = new Region();
		region.name = name;
		region.minX = Math.min(x1, x2);
		region.maxX = Math.max(x1, x2);
		region.minZ = Math.min(z1, z2);
		region.maxZ = Math.max(z1, z2);
		all().add(region);
		save();
	}

	public static boolean remove(String name) {
		boolean removed = all().removeIf(r -> r.name.equalsIgnoreCase(name));
		if (removed) {
			save();
		}
		return removed;
	}

	public static void clear() {
		all().clear();
		save();
	}

	private static void save() {
		try {
			Files.writeString(path(), GSON.toJson(all()));
		} catch (IOException ignored) {
			// Not being able to save is not worth a crash.
		}
	}
}

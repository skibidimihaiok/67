package com.suschunkfinder;

/** Hides the trim patterns on armor, on yourself and on others. */
public final class ArmorTrimHiderModule extends ClientModule {
	public ArmorTrimHiderModule() {
		super("Armor Trim Hider", "Hides the trim patterns on armor.", Category.RENDER);
	}
}

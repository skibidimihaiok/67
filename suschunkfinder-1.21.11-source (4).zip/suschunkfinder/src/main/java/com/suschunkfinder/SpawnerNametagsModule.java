package com.suschunkfinder;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.level.block.entity.SpawnerBlockEntity;
import net.minecraft.world.phys.Vec3;

/** Labels over spawners the server sent you, with the distance. */
public final class SpawnerNametagsModule extends ClientModule {
	private final NumberSetting range = add(NumberSetting.of("Range (chunks)", 8, 1, 32, 1));

	public SpawnerNametagsModule() {
		super("Spawner Nametags", "Shows a label over spawners with the distance.", Category.RENDER);
	}

	@Override
	public void renderHud(GuiGraphics g) {
		Minecraft client = Minecraft.getInstance();
		if (client.player == null) {
			return;
		}
		float pt = client.getDeltaTracker().getGameTimeDeltaPartialTick(false);
		EspUtil.forEachBlockEntity(range.getInt(), be -> {
			if (!(be instanceof SpawnerBlockEntity)) {
				return;
			}
			Vec3 center = Vec3.atCenterOf(be.getBlockPos()).add(0, 0.9, 0);
			int[] p = Projector.toScreen(center, pt, g.guiWidth(), g.guiHeight());
			if (p == null) {
				return;
			}
			int distance = (int) client.player.position().distanceTo(Vec3.atCenterOf(be.getBlockPos()));
			String label = "Spawner  " + distance + "m";
			int w = Hud.width(label);
			g.fill(p[0] - w / 2 - 3, p[1] - 3, p[0] + w / 2 + 3, p[1] + 10, Hud.PANEL);
			Hud.text(g, label, p[0] - w / 2, p[1], 0xFFD7A0FF);
		});
	}
}

package com.suschunkfinder;

import net.minecraft.client.Minecraft;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

/** Gives your own game a night vision effect so everything is bright. Nothing is sent to the server. */
public final class FullbrightModule extends ClientModule {
	public FullbrightModule() {
		super("Fullbright", "Makes everything bright, like night vision.", Category.RENDER);
	}

	@Override
	public void tick(Minecraft client) {
		if (client.player != null && !client.player.hasEffect(MobEffects.NIGHT_VISION)) {
			client.player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 1000000, 0, false, false, false));
		}
	}

	@Override
	protected void onDisable() {
		Minecraft client = Minecraft.getInstance();
		if (client.player != null) {
			client.player.removeEffect(MobEffects.NIGHT_VISION);
		}
	}
}

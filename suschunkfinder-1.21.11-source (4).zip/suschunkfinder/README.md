# Sus Chunk Finder (Fabric, Minecraft 1.21.11)

Client-side mod. Reads chunk data the server sends and highlights chunks that hold signs of a base.

- Red slab: flagged blocks found (chests, barrels, spawners, dispensers, pistons, shulker boxes, hoppers, droppers, observers, comparators, repeaters).
- Green slab (prime chunk): the chunk has a block that never generates naturally (shulker box, hopper, dropper, observer, comparator, repeater).
- The slab sits at the average height of the flagged blocks, so you can tell how deep the base is.

## Client menu
Press **U** (rebindable in Options > Controls > Key Binds) to open the menu. Tabs on top, click a module to turn it on or off, **Set** opens its settings.

Press U, pick a tab, click a module to turn it on or off, press Set for its settings. Every module is configurable.
HUD modules have X and Y settings to move them. Everything is saved to config/suschunkfinder-client.json.

## Commands (client side, never sent to the server)
/suschunk toggle
/suschunk red <n>      flagged blocks needed for red (default 2)
/suschunk prime <n>    never-natural blocks needed for green (default 1)
/suschunk range <n>    draw distance in chunks (default 32)
/suschunk alpha <0.1-1>
/suschunk notify       toggle the chat message with spawner coordinates
/suschunk chestmax <y>  chests above this height are ignored (default -64)
/suschunk miny <y>      ignore blocks below this height (default 0; use -64 to include deepslate)
/suschunk info         what the scanner found in your current chunk

Settings are saved to config/suschunkfinder.json.

## Build
1. Easiest: generate a project at https://fabricmc.net/develop/template (Minecraft 1.21.11, Mojang mappings,
   no split sources, no data generation), then copy `src/main/java/com/suschunkfinder` and
   `src/main/resources/fabric.mod.json` into it. This also gives you the correct Gradle wrapper.
2. Or use the build files here with Gradle 9.x.
3. Run `./gradlew build`. The mod jar is in build/libs/ (use the one without -sources).
4. Needs Fabric API 0.141.x for 1.21.11 and Java 21.

## Configs
/suschunk config save <name>, /suschunk config load <name>, /suschunk config list

## Extra commands
/suschunk region add <name> <x1> <z1> <x2> <z2> | remove <name> | list | clear
/suschunk friends add|remove|list <name>      (used by Auto TPA and Spawner Protect)
/suschunk staff add|remove|list <name>        (used by Staff List)
/suschunk base set|clear|info                 (Spawner Protect)
/suschunk macro set <1-3> <text> | run <n> | list
/suschunk blocks add|remove|list <block id>   (Block List, shown by Block ESP)
/suschunk spotify id <ClientID> | login | play | pause | next | prev

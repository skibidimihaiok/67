# SusChunkFinder module source patch (Minecraft 1.21.11)

This ZIP contains the complete source project with the following real source additions integrated under
`src/main/java/com/suschunkfinder/`:

- `ModuleKeybinds.java` — registers an independent, rebindable key mapping for every module currently
  registered in `ModuleManager`.
- `TotemCounterModule.java`
- `PingDisplayModule.java`
- `CoordinatesHudModule.java`
- `ReachDisplayModule.java`
- `InventoryHudModule.java`
- `TargetHudModule.java`
- `AutoSprintModule.java`
- `AutoToolModule.java`

`ModuleManager.java` registers the new modules. `Keys.java` starts module-key registration after the
module list has been initialized. The language file contains labels for the new keybinds.

## Configure module keybinds

Launch the client, open **Options -> Controls -> Key Binds**, then find the **Sus Chunk Finder**
category. Every registered module has its own key mapping. The default is unbound; click the mapping
and press the key you want. This includes modules that were already in the client, not just the new ones.

## Build in IntelliJ IDEA

1. Extract this ZIP.
2. Open the extracted project folder (the folder containing `settings.gradle`) in IntelliJ IDEA.
3. Use Java 21 and allow Gradle to sync.
4. Run the Gradle `build` task. The output JAR will be under `build/libs/`.

## Scope / honesty note

This is not a claim that every item in the very large requested list has been implemented. This patch
adds the eight modules listed above as working source implementations, keeps the existing modules,
and adds per-module keybinds to all registered modules. The earlier requested items that require
substantial separate game logic or server-specific behavior (for example Aura, Auto Crystal, Elytra
Freeze, Surround Miner, custom chat transformation, BoxPvP, and server-specific helpers) are not
silently represented as working modules or empty placeholders.

The source project targets Minecraft 1.21.11 / Java 21. A build could not be run in this environment
because the Gradle wrapper distribution was not cached and network access to services.gradle.org was
unavailable. Please run Gradle build in IntelliJ to verify against your local dependency cache.

package com.suschunkfinder;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.loader.api.FabricLoader;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/** Holds every module and saves their on/off state and settings to config/suschunkfinder-client.json. */
public final class ModuleManager {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final List<ClientModule> MODULES = new ArrayList<>();
	private static boolean loading;

	private ModuleManager() {
	}

	public static void init() {
		// Render
		MODULES.add(new SusChunkModule());
		MODULES.add(new PlayerEspModule());
		MODULES.add(new MobEspModule());
		MODULES.add(new StorageEspModule());
		MODULES.add(new BlockEntityEspModule());
		MODULES.add(new BlockEspModule());
		MODULES.add(new BlockListModule());
		MODULES.add(new HoleEspModule());
		MODULES.add(new BlockOutlineModule());
		MODULES.add(new JumpCirclesModule());
		MODULES.add(new NameTagsModule());
		MODULES.add(new SpawnerNametagsModule());
		MODULES.add(new RadarModule());
		MODULES.add(new RegionMapModule());
		MODULES.add(new ArmorHudModule());
        MODULES.add(new TotemCounterModule());
        MODULES.add(new CoordinatesHudModule());
        MODULES.add(new ReachDisplayModule());
        MODULES.add(new InventoryHudModule());
        MODULES.add(new TargetHudModule());
        MODULES.add(new PingDisplayModule());
		MODULES.add(new PotionsModule());
		MODULES.add(new FullbrightModule());
		MODULES.add(new ZoomModule());
		MODULES.add(new CustomFovModule());
		MODULES.add(new CustomCrosshairModule());
		MODULES.add(new HitParticlesModule());
		MODULES.add(new SwingSpeedModule());
		MODULES.add(new FreeLookModule());
		MODULES.add(new CustomGlintModule());
		MODULES.add(new ArmorTrimHiderModule());
		// Movement
		MODULES.add(new AutoWalkModule());
        MODULES.add(new AutoSprintModule());
		MODULES.add(new FreecamModule());
		// Macro
		MODULES.add(new ChatMacroModule());
		MODULES.add(new AutoTpaModule());
		// Client
		MODULES.add(new WatermarkModule());
		MODULES.add(new InfoModule());
		MODULES.add(new KeystrokesModule());
		MODULES.add(new ArrayListModule());
		MODULES.add(new NotificationsModule());
		MODULES.add(new SpotifyModule());
		MODULES.add(new HudManagerModule());
		MODULES.add(new IconPickerModule());
		MODULES.add(new ThemeModule());
		MODULES.add(new ClickGuiModule());
		// Misc
		MODULES.add(new StaffListModule());
		MODULES.add(new SpawnerProtectModule());
		MODULES.add(new WeatherNotifierModule());
		MODULES.add(new CoordSnapperModule());
		MODULES.add(new NameProtectModule());
		MODULES.add(new SkinProtectModule());
		MODULES.add(new FastUseModule());
        MODULES.add(new AutoToolModule());
		load();

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			for (ClientModule module : MODULES) {
				if (!module.isEnabled()) {
					continue;
				}
				try {
					module.tick(client);
				} catch (Exception ignored) {
					// One broken module should never crash the game.
				}
			}
		});
	}

	/** Finds a module by its class. */
	public static <T extends ClientModule> T find(Class<T> type) {
		for (ClientModule module : MODULES) {
			if (type.isInstance(module)) {
				return type.cast(module);
			}
		}
		return null;
	}

	/** Reads the config file again, used after loading a saved config. */
	public static void reload() {
		load();
	}

	public static List<ClientModule> all() {
		return MODULES;
	}

	public static List<ClientModule> in(ClientModule.Category category) {
		List<ClientModule> list = new ArrayList<>();
		for (ClientModule module : MODULES) {
			if (module.category == category) {
				list.add(module);
			}
		}
		return list;
	}

	public static void renderHud(GuiGraphics graphics) {
		Minecraft client = Minecraft.getInstance();
		if (client.player == null || client.options.hideGui) {
			return;
		}
		for (ClientModule module : MODULES) {
			if (!module.isEnabled()) {
				continue;
			}
			try {
				module.renderHud(graphics);
			} catch (Exception ignored) {
				// One broken HUD element should never crash the game.
			}
		}
	}

	private static Path path() {
		return FabricLoader.getInstance().getConfigDir().resolve("suschunkfinder-client.json");
	}

	public static void save() {
		if (loading) {
			return;
		}
		Map<String, Map<String, Object>> out = new LinkedHashMap<>();
		for (ClientModule module : MODULES) {
			if (!module.persists()) {
				continue;
			}
			Map<String, Object> values = new LinkedHashMap<>();
			values.put("enabled", module.isEnabled());
			for (Setting setting : module.settings()) {
				values.put(setting.name, setting.save());
			}
			out.put(module.name, values);
		}
		try {
			Files.writeString(path(), GSON.toJson(out));
		} catch (IOException ignored) {
			// Not being able to save is not worth a crash.
		}
	}

	private static void load() {
		loading = true;
		try {
			Path p = path();
			if (!Files.exists(p)) {
				return;
			}
			Type type = new TypeToken<Map<String, Map<String, Object>>>() { }.getType();
			Map<String, Map<String, Object>> in = GSON.fromJson(Files.readString(p), type);
			if (in == null) {
				return;
			}
			for (ClientModule module : MODULES) {
				Map<String, Object> values = in.get(module.name);
				if (values == null) {
					continue;
				}
				if (values.get("enabled") instanceof Boolean on) {
					module.setEnabled(on);
				}
				for (Setting setting : module.settings()) {
					if (values.containsKey(setting.name)) {
						setting.load(values.get(setting.name));
					}
				}
			}
		} catch (Exception ignored) {
			// A broken config file just means defaults.
		} finally {
			loading = false;
		}
	}
}

package com.suschunkfinder;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.item.Items;

/** Displays the number of totems in the player's inventory and offhand. */
public final class TotemCounterModule extends HudModule {
    public TotemCounterModule() {
        super("Totem Counter", "Shows how many totems you are carrying.", Category.RENDER, 5, 205);
    }

    @Override
    protected void draw(GuiGraphics g, int x, int y) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        int count = mc.player.getInventory().countItem(Items.TOTEM_OF_UNDYING);
        if (mc.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) count++;
        Hud.text(g, "Totems: " + count, x, y, count == 0 ? 0xFFFF5555 : Hud.WHITE);
    }
}

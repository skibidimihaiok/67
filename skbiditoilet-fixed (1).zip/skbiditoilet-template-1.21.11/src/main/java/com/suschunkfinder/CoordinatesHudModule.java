package com.suschunkfinder;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/** Displays the player's block coordinates. */
public final class CoordinatesHudModule extends HudModule {
    private final BoolSetting showDimension = add(BoolSetting.of("Show dimension", true));

    public CoordinatesHudModule() {
        super("Coordinates HUD", "Displays your current XYZ coordinates.", Category.CLIENT, 5, 235);
    }

    @Override
    protected void draw(GuiGraphics g, int x, int y) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        var pos = mc.player.blockPosition();
        Hud.text(g, "XYZ: " + pos.getX() + " " + pos.getY() + " " + pos.getZ(), x, y, Hud.WHITE);
        if (showDimension.get() && mc.level != null) {
            String dim = mc.level.dimension().location().toString();
            Hud.text(g, dim, x, y + 10, 0xFFB8B8B8);
        }
    }
}

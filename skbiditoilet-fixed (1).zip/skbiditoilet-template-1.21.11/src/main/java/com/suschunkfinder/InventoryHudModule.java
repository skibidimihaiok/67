package com.suschunkfinder;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.item.ItemStack;

/** Draws the player's hotbar inventory as a compact HUD strip. */
public final class InventoryHudModule extends HudModule {
    private final BoolSetting showEmpty = add(BoolSetting.of("Show empty slots", true));

    public InventoryHudModule() {
        super("Inventory HUD", "Displays your hotbar items on screen.", Category.CLIENT, 5, 265);
    }

    @Override
    protected void draw(GuiGraphics g, int x, int y) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getItem(i);
            if (stack.isEmpty() && !showEmpty.get()) continue;
            int sx = x + i * 20;
            g.fill(sx - 1, y - 1, sx + 17, y + 17, 0x88000000);
            if (!stack.isEmpty()) g.renderItem(stack, sx, y);
            if (!stack.isEmpty() && stack.getCount() > 1) {
                g.renderItemDecorations(mc.font, stack, sx, y);
            }
        }
    }
}

package com.suschunkfinder;

import net.minecraft.client.Minecraft;

/** Holds sprint while the player is moving forward. */
public final class AutoSprintModule extends ClientModule {
    public AutoSprintModule() {
        super("Auto Sprint", "Automatically sprints while moving forward.", Category.MOVEMENT);
    }

    @Override
    public void tick(Minecraft client) {
        if (client.player == null || client.screen != null) return;
        boolean moving = client.options.keyUp.isDown();
        client.options.keySprint.setDown(moving);
    }

    @Override
    protected void onDisable() {
        Minecraft.getInstance().options.keySprint.setDown(false);
    }
}

package com.suschunkfinder;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.LivingEntity;

/** Compact information panel for the living entity under the crosshair. */
public final class TargetHudModule extends HudModule {
    public TargetHudModule() {
        super("Target HUD", "Shows name and health of the entity under your crosshair.", Category.COMBAT, 5, 285);
    }

    @Override
    protected void draw(GuiGraphics g, int x, int y) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || !(mc.hitResult instanceof net.minecraft.world.phys.EntityHitResult hit)
                || !(hit.getEntity() instanceof LivingEntity target)) return;
        String name = target.getName().getString();
        float health = Math.max(0, target.getHealth());
        float max = Math.max(1, target.getMaxHealth());
        g.fill(x - 3, y - 3, x + 145, y + 25, 0xAA101018);
        Hud.text(g, name + "  " + String.format(java.util.Locale.ROOT, "%.1f", health) + "/" +
                String.format(java.util.Locale.ROOT, "%.1f", max), x, y, Hud.WHITE);
        g.fill(x, y + 12, x + 136, y + 17, 0xFF444444);
        g.fill(x, y + 12, x + Math.round(136 * Math.min(1f, health / max)), y + 17, 0xFF55DD77);
    }
}

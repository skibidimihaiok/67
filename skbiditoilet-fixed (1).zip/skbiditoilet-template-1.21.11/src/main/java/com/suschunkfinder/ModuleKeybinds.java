package com.suschunkfinder;

import java.util.LinkedHashMap;
import java.util.Map;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;

/**
 * Registers one independently rebindable vanilla key mapping for every module.
 * Players can change these in Options > Controls > Key Binds.
 */
public final class ModuleKeybinds {
    private static final Map<ClientModule, KeyMapping> BINDS = new LinkedHashMap<>();
    private static boolean registered;

    private ModuleKeybinds() {}

    public static void register() {
        if (registered) return;
        registered = true;
        for (ClientModule module : ModuleManager.all()) {
            String id = module.name.toLowerCase(java.util.Locale.ROOT)
                    .replaceAll("[^a-z0-9]+", "_").replaceAll("^_|_$", "");
            KeyMapping mapping = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                    "key.suschunkfinder.module." + id,
                    InputConstants.Type.KEYSYM,
                    InputConstants.UNKNOWN.getValue(),
                    Keys.CATEGORY));
            BINDS.put(module, mapping);
        }
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            for (Map.Entry<ClientModule, KeyMapping> entry : BINDS.entrySet()) {
                while (entry.getValue().consumeClick()) {
                    entry.getKey().setEnabled(!entry.getKey().isEnabled());
                }
            }
        });
    }
}

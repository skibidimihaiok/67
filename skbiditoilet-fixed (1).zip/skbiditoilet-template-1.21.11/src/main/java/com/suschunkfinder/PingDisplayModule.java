package com.suschunkfinder;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/** Displays the local player's server latency. */
public final class PingDisplayModule extends HudModule {
    public PingDisplayModule() {
        super("Ping Display", "Shows your current server ping.", Category.CLIENT, 5, 220);
    }

    @Override
    protected void draw(GuiGraphics g, int x, int y) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.getConnection() == null) return;
        var info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
        if (info != null) Hud.text(g, "Ping: " + info.getLatency() + " ms", x, y, Hud.WHITE);
    }
}

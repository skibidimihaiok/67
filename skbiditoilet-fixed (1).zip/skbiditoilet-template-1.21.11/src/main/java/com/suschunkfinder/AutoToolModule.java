package com.suschunkfinder;

import net.minecraft.client.Minecraft;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/** Selects the hotbar tool with the highest destroy speed for the targeted block while mining. */
public final class AutoToolModule extends ClientModule {
    public AutoToolModule() {
        super("Auto Tool", "Selects the strongest hotbar tool for the block you are mining.", Category.MISC);
    }

    @Override
    public void tick(Minecraft client) {
        if (client.player == null || client.level == null || client.screen != null
                || !client.options.keyAttack.isDown()
                || !(client.hitResult instanceof BlockHitResult hit)) return;
        BlockState state = client.level.getBlockState(hit.getBlockPos());
        int bestSlot = client.player.getInventory().getSelectedSlot();
        float bestSpeed = client.player.getInventory().getItem(bestSlot).getDestroySpeed(state);
        for (int i = 0; i < 9; i++) {
            float speed = client.player.getInventory().getItem(i).getDestroySpeed(state);
            if (speed > bestSpeed) {
                bestSpeed = speed;
                bestSlot = i;
            }
        }
        client.player.getInventory().setSelectedSlot(bestSlot);
    }
}

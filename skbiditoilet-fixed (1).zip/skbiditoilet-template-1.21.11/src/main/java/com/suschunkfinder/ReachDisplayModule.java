package com.suschunkfinder;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.Entity;

/** Displays distance to the entity currently under the crosshair. */
public final class ReachDisplayModule extends HudModule {
    private final NumberSetting decimals = add(NumberSetting.of("Decimals", 1, 0, 2, 1));

    public ReachDisplayModule() {
        super("Reach Display", "Shows distance to the entity under your crosshair.", Category.CLIENT, 5, 250);
    }

    @Override
    protected void draw(GuiGraphics g, int x, int y) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || !(mc.hitResult instanceof net.minecraft.world.phys.EntityHitResult hit)) return;
        Entity entity = hit.getEntity();
        double distance = mc.player.distanceTo(entity);
        String format = decimals.getInt() == 0 ? "%.0f" : decimals.getInt() == 2 ? "%.2f" : "%.1f";
        Hud.text(g, "Reach: " + String.format(java.util.Locale.ROOT, format, distance), x, y, Hud.WHITE);
    }
}
